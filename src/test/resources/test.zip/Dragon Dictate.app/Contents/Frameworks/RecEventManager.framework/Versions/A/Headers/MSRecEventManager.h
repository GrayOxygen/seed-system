//
//  MSRecEventManager.h
//  MSRecEventManager
//
//  Created by Paul Herzog on 4/30/08.
//  Copyright 2008 MacSpeech, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "RecEventMO.h"

@interface MSRecEventManager : NSObject {
	NSManagedObjectContext *moc;
  NSString *appBundleID;
  NSString *documentName;
  NSString *windowTitle;
  NSString *mode;
  NSString *grammar;
  NSString *clientName;
  NSString *referenceName;
  
  BOOL readOnly;
  NSString *dataStoreVersion;
}


#pragma mark Initialization and Termination
//+ (MSRecEventManager *)sharedManager;
- (id)initWithFilePath:(NSString *)filePath limitedToReadOnly:(BOOL)readOnlyRequested;

- (void)reset;
- (BOOL)save:(NSError **)error;
- (void)useAlternateFile:(NSString *)alternateFile limitedToReadOnly:(BOOL)readOnlyRequested;

#pragma mark -
#pragma mark Accessors
+ (NSString *)recEventStorePath;
+ (NSString *)recEventStorePathWithFileName:(NSString *)fileName;
- (NSManagedObjectContext *)managedObjectContext;
- (NSString *)appBundleID;
- (void)setAppBundleID:(NSString *)value;
- (NSString *)documentName;
- (void)setDocumentName:(NSString *)value;
- (NSString *)windowTitle;
- (void)setWindowTitle:(NSString *)value;
- (NSString *)mode;
- (void)setMode:(NSString *)value;
- (NSString *)grammar;
- (void)setGrammar:(NSString *)value;
- (NSString *)referenceName;
- (void)setReferenceName:(NSString *)value;
- (NSString *)dataStoreVersion;
- (void)setDataStoreVersion:(NSString *)value;
- (NSString *)clientName;
- (void)setClientName:(NSString *)value;




#pragma mark -
#pragma mark Recognition Event Management
- (RecEventMO *)insertCommentWithText:(NSString *)commentText;
- (RecEventMO *)insertInvocationWithData:(NSData *)invocationData;
- (RecEventMO *)insertEventWithText:(NSString *)eventText atPosition:(NSRange)position;
- (RecEventMO *)insertEventWithText:(NSString *)eventText atPosition:(NSRange)position fromResultData:(void *)eventData;
- (void)deleteEvent:(RecEventMO *)recEvent;

#pragma mark -
#pragma mark Retrieve Recognition Events
- (NSArray *)recEvents:(NSError **)error;
- (NSArray *)recEventsContainingText:(NSString *)text error:(NSError **)error;
- (NSArray *)recEventsForGrammar:(NSString *)grammar containingText:(NSString *)text error:(NSError **)error;
- (NSArray *)recEventsForMode:(NSString *)mode containingText:(NSString *)text error:(NSError **)error;
- (NSArray *)recEventsForAppBundle:(NSString *)appBundle containingText:(NSString *)text error:(NSError **)error;
- (NSArray *)fetchRecEventsWhereAttribute:(NSString *)attribute hasValue:(NSString *)value containingText:(NSString *)text error:(NSError **)error;
- (NSArray *)fetchRecEventsWithCondition:(NSString *)condition error:(NSError **)error;

@end
