#import "_RecEventMO.h"
//#import "dsx.h"

/*
typedef struct {
    void    *pData;
    unsigned long    dwSize;
} DSXSDATA, * PDSXSDATA;
*/

// these are faux modes, not suitable for setMode
extern NSString * const RE_MSModeIdle;
extern NSString * const RE_MSModeCorrection;

// these are real modes and can be passed to setMode
extern NSString * const RE_MSModeDictation;
extern NSString * const RE_MSModeCommand;
extern NSString * const RE_MSModeSpelling;
extern NSString * const RE_MSModeNumbers;
extern NSString * const RE_MSModeSetUpMyMic;
extern NSString * const RE_MSModeLearnMyVoice;
extern NSString * const RE_MSModePronounce;
extern NSString * const RE_MSModeTranscribing;
extern NSString * const RE_MSModeRetraining;
extern NSString * const RE_MSModeLearnMyWritingStyle;
extern NSString * const RE_MSModeWelcomeWindow;

@interface RecEventMO : _RecEventMO {}

#pragma mark -
#pragma mark Accessors
+ (NSSet *)validModes;
+ (NSDictionary *)modeNames;
+ (BOOL)isValidMode:(NSString *)recEventMode;

- (void)setEventPosition:(NSRange)eventRange;
- (NSRange)eventPosition;
- (BOOL)didCopyResultDataInto:(void *)resultDataSource;
- (void)setResultData:(void *)resultDataSource;

- (NSString *)shortDescription;

- (BOOL)isRecognitionEvent;
- (BOOL)isInvocation;
- (BOOL)isComment;
- (NSString *)displayText;

@end
