// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to RecEventMO.h instead.

#import <CoreData/CoreData.h>
#import "MSMOBase2.h"


@interface RecEventMOID : NSManagedObjectID {}
@end

@interface _RecEventMO : MSMOBase2 {}
+ (id)newInManagedObjectContext:(NSManagedObjectContext*)moc_;
- (RecEventMOID*)objectID;



- (NSData*)data;
- (void)setData:(NSData*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSData *data;
#endif

//- (BOOL)validateData:(id*)value_ error:(NSError**)error_;



- (NSString*)appBundleID;
- (void)setAppBundleID:(NSString*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSString *appBundleID;
#endif

//- (BOOL)validateAppBundleID:(id*)value_ error:(NSError**)error_;



- (NSString*)windowTitle;
- (void)setWindowTitle:(NSString*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSString *windowTitle;
#endif

//- (BOOL)validateWindowTitle:(id*)value_ error:(NSError**)error_;



- (NSNumber*)phraseFlags;
- (void)setPhraseFlags:(NSNumber*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSNumber *phraseFlags;
#endif

- (NSInteger)phraseFlagsValue;
- (void)setPhraseFlagsValue:(NSInteger)value_;

//- (BOOL)validatePhraseFlags:(id*)value_ error:(NSError**)error_;



- (NSString*)text;
- (void)setText:(NSString*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSString *text;
#endif

//- (BOOL)validateText:(id*)value_ error:(NSError**)error_;



- (NSString*)documentName;
- (void)setDocumentName:(NSString*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSString *documentName;
#endif

//- (BOOL)validateDocumentName:(id*)value_ error:(NSError**)error_;



- (NSNumber*)eventLength;
- (void)setEventLength:(NSNumber*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSNumber *eventLength;
#endif

- (NSInteger)eventLengthValue;
- (void)setEventLengthValue:(NSInteger)value_;

//- (BOOL)validateEventLength:(id*)value_ error:(NSError**)error_;



- (NSString*)grammar;
- (void)setGrammar:(NSString*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSString *grammar;
#endif

//- (BOOL)validateGrammar:(id*)value_ error:(NSError**)error_;



- (NSNumber*)phraseCount;
- (void)setPhraseCount:(NSNumber*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSNumber *phraseCount;
#endif

- (NSInteger)phraseCountValue;
- (void)setPhraseCountValue:(NSInteger)value_;

//- (BOOL)validatePhraseCount:(id*)value_ error:(NSError**)error_;



- (NSDate*)timestamp;
- (void)setTimestamp:(NSDate*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSDate *timestamp;
#endif

//- (BOOL)validateTimestamp:(id*)value_ error:(NSError**)error_;



- (NSNumber*)eventLocation;
- (void)setEventLocation:(NSNumber*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSNumber *eventLocation;
#endif

- (NSInteger)eventLocationValue;
- (void)setEventLocationValue:(NSInteger)value_;

//- (BOOL)validateEventLocation:(id*)value_ error:(NSError**)error_;



- (NSString*)eventType;
- (void)setEventType:(NSString*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSString *eventType;
#endif

//- (BOOL)validateEventType:(id*)value_ error:(NSError**)error_;



- (NSString*)referenceName;
- (void)setReferenceName:(NSString*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSString *referenceName;
#endif

//- (BOOL)validateReferenceName:(id*)value_ error:(NSError**)error_;



- (NSString*)clientName;
- (void)setClientName:(NSString*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSString *clientName;
#endif

//- (BOOL)validateClientName:(id*)value_ error:(NSError**)error_;



- (NSString*)mode;
- (void)setMode:(NSString*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSString *mode;
#endif

//- (BOOL)validateMode:(id*)value_ error:(NSError**)error_;



- (NSString*)notes;
- (void)setNotes:(NSString*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSString *notes;
#endif

//- (BOOL)validateNotes:(id*)value_ error:(NSError**)error_;



@end
