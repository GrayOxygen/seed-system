//
//  MSMOBase2.h
//  MSRecEventManager
//
//  Created by Paul Herzog on 6/26/08.
//  Copyright 2008 MacSpeech, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface MSMOBase2 : NSManagedObject {

}

#pragma mark
#pragma mark Abstract Representation
- (NSString *)abstractRepresentation;
- (NSSet *)attributesForRepresentation;
- (BOOL)isEqualToRepresentationOf:(MSMOBase2 *)otherObject;
+ (NSMutableSet *)representationsForObjectsInSet:(NSSet *)set;

@end
