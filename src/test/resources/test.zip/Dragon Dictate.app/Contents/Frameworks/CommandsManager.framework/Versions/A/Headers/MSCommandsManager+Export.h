//
//  MSCommandsManager+Export.h
//  MSCommandsManager
//
//  Created by Paul Herzog on 8/13/10.
//  Copyright 2010 Nuance Communications, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "MSCommandsManager.h"

@class CommandExportOperation;
@class TriggerMO;

@interface MSCommandsManager(Export)

#pragma mark -
#pragma mark Command Exporting
- (BOOL)exportCommands:(NSArray *)commands asVendor:(NSString *)vendor toStoreAtPath:(NSString *)storePath storeType:(NSString *)storeType error:(NSError **)error;
//- (BOOL)exportCommandKeys:(NSSet *)selectedKeys withOriginalVendor:(BOOL)preserveVendor toStoreAtPath:(NSString *)storePath storeType:(NSString *)storeType error:(NSError **)error;
//- (BOOL)exportCommandKeys:(NSSet *)selectedKeys withOriginalVendor:(BOOL)preserveVendor language:(NSString *)language toStoreAtPath:(NSString *)storePath storeType:(NSString *)storeType error:(NSError **)error;
- (BOOL)didExportOperation:(CommandExportOperation *)exportOperation;
- (NSMutableDictionary *)hiddenCommandInfoForIdentifier:(NSString *)contextIdentifier version:(NSNumber *)versionNum;

#pragma mark -
#pragma mark Dynamic Data Exporting
- (BOOL)didSaveTerms:(NSSet *)terms storePath:(NSString *)storePath storeType:(NSString *)storeType error:(NSError **)error;
- (void)gatherDynamicDataForTrigger:(TriggerMO *)trigger inExportOperation:(CommandExportOperation *)exportOperation;

#pragma mark -
#pragma mark XML Output
- (BOOL)xmlCommandKeys:(NSSet *)selectedKeys withOriginalVendor:(BOOL)preserveVendor language:(NSString *)language toFileAtPath:(NSString *)filePath error:(NSError **)error;


@end
