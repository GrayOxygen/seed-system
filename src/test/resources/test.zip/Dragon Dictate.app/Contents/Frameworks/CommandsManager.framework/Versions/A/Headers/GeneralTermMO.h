//
//  GeneralTermMO.h
//
//  Created by Paul Herzog
//  Copyright 2010 Nuance Communications, Inc. All rights reserved.
//

#import "_GeneralTermMO.h"

// Term Types
extern NSString *SYNONYM_TERM_TYPE;
extern NSString *ALTERNATIVE_TERM_TYPE;
extern NSString *SPEECH_TERM_TYPE;

@interface GeneralTermMO : _GeneralTermMO {}
// Custom logic goes here.
@end
