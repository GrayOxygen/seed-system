//
//  LocationMO.h
//
//  Created by Paul Herzog
//  Copyright 2007 MacSpeech, Inc. All rights reserved.
//

#import "_LocationMO.h"

@interface LocationMO : _LocationMO {}

- (NSString *)shortDescription;

@end
