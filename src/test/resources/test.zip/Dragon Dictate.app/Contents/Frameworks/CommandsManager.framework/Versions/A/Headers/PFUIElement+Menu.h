//
//  PFUIElement+Menu.h
//  Dictate
//
//  Created by Paul Herzog on 12/27/11.
//  Copyright (c) 2011 N/A. All rights reserved.
//

#import <PFAssistive/PFAssistive.h>

@interface PFUIElement(Menu)
- (NSString *)name;
- (PFUIElement *)subMenu;
- (NSMenu *)appKitMenuNamed:(NSString *)menuName withAction:(SEL)menuAction 
                usingFilter:(BOOL (^)(PFApplicationUIElement *uiApp, PFUIElement *uiMenu, PFUIElement *uiMenuItem))menuItemFilter;

@end
