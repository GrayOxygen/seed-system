//
//  ActionMO+Workflow.h
//  MSCommandsManager
//
//  Created by Paul Herzog on 5/31/10.
//  Copyright 2010 Nuance Communications, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "ActionMO.h"


@interface ActionMO(Workflow)

#pragma mark -
#pragma mark Workflow Execution
- (BOOL)executeAMWorkflowWithVariables:(NSDictionary *)variables;
- (BOOL)executeWorkflowWithVariables:(NSDictionary *)variables;

#if 0
- (NSString *)automatorLauncher;
- (NSString *)pathForAutomatorRunner;
- (NSString *)scriptTextForWorkflow:(NSString *)workflowPath;
- (BOOL)useAppleScriptToLaunchWorkflow:(NSString *)workflowPath;
#endif


@end
