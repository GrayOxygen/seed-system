//
//  MSFileMonitoring.h
//  MSCommandsManager
//
//  Created by Paul Herzog on 1-Aug-2007.
//  Copyright 2007 MacSpeech, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@protocol MSFileMonitoring<NSObject>

#pragma mark
#pragma mark File Monitoring
- (BOOL)shouldContinueMonitoringModifiedFileNamed:(NSString *)fileName;
- (void)deletedFileNamed:(NSString *)fileName;

@end
