//
//  MSDirectoryMonitoring.h
//  MSCommandsManager
//
//  Created by Paul Herzog on 1-Aug-2007.
//  Copyright 2007 MacSpeech, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@protocol MSDirectoryMonitoring<NSObject>

#pragma mark
#pragma mark Directory Monitoring

- (void)addedFileNamed:(NSString *)fileName toDirectory:(NSString *)directoryName;
- (void)deletedFileNamed:(NSString *)fileName fromDirectory:(NSString *)directoryName; 

@end
