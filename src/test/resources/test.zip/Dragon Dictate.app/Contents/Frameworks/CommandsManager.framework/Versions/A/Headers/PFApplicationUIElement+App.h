//
//  PFApplicationUIElement+App.h
//  Dictate
//
//  Created by Paul Herzog on 12/27/11.
//  Copyright (c) 2011 N/A. All rights reserved.
//

#import <PFAssistive/PFAssistive.h>

@interface PFApplicationUIElement(App)
- (NSString *)name;
- (NSMenu *)appKitMenuWithAction:(SEL)menuAction 
                     usingFilter:(BOOL (^)(PFApplicationUIElement *uiApp, PFUIElement *uiMenu, PFUIElement *uiMenuItem))menuItemFilter;

@end
