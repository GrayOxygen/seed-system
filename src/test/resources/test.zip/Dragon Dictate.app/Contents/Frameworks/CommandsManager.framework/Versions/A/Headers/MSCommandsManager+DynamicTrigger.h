//
//  MSCommandsManager+DynamicTrigger.h
//  MSCommandsManager
//
//  Created by Paul Herzog on 4/19/10.
//  Copyright 2010 MacSpeech, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "MSCommandsManager.h"

@class GeneralTermMO;

@interface MSCommandsManager(DynamicTrigger)

- (NSManagedObjectContext *)dynamicTriggerMoc;
- (NSArray *)dynamicTriggers;
- (BOOL)didSaveDynamicTriggers:(NSError **)error;

- (GeneralTermMO *)generalTermNamed:(NSString *)termName contextID:(NSString *)contextIdentifier;
- (GeneralTermMO *)generalTermNamed:(NSString *)termName contextID:(NSString *)contextIdentifier language:(NSString *)language;

- (NSSet *)specificTermsForGeneralTermNamed:(NSString *)termName contextID:(NSString *)contextIdentifier;
- (NSSet *)specificTermsForGeneralTermNamed:(NSString *)termName contextID:(NSString *)contextIdentifier language:(NSString *)language;

- (NSArray *)namesForSpecificTerms:(NSSet *)terms;

- (NSArray *)namesForGeneralTermNamed:(NSString *)termName contextID:(NSString *)contextIdentifier;
- (NSArray *)namesForGeneralTermNamed:(NSString *)termName contextID:(NSString *)contextIdentifier language:(NSString *)language;

- (void)addGeneralTermForContextID:(NSString *)contextIdentifier derivedFrom:(GeneralTermMO *)generalTerm;
- (BOOL)didDeleteDynamicTermsForContextID:(NSString *)contextIdentifier;

@end
