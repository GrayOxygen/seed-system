//
//  NSManagedObjectContext+Utilities.h
//  MSCommandsManager
//
//  Created by Paul Herzog on 27-Jul-2007.
//  Copyright 2007 MacSpeech, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface NSManagedObjectContext(Utilities)

#pragma mark
#pragma mark Store Metadata
- (id)firstInMemoryStore;
- (NSString *)storeTypeForStoreAtURL:(NSURL *)storeURL;
- (NSManagedObjectModel*)managedObjectModel;

#pragma mark
#pragma mark Action Methods
- (id)attachEmptyStoreAtURL:(NSURL *)storeURL storeType:(NSString *)storeType error:(NSError **)error;
- (NSManagedObjectContext *)cloneContextWithoutStores;
- (NSManagedObject *)MSCloneObject:(NSManagedObject *)originalObject fromOriginalSchema:(BOOL)fromOriginalSchema;
- (NSManagedObject *)MSCloneObject:(NSManagedObject *)originalObject;
- (NSArray *)objectsOfType:(NSString *)entityType inStore:(id)store withCondition:(NSString *)condition error:(NSError **)error;
- (NSArray *)objectsOfType:(NSString *)entityType inStore:(id)store withCondition:(NSString *)condition sortedBy:(NSString *)sortExpression error:(NSError **)error;
- (NSFetchRequest *)createFetchRequestForEntity:(NSString *)entityName inStore:(id)baseStore;
- (NSArray *)executeFetch:(NSFetchRequest *)fetchRequest predicate:(NSPredicate *)predicate error:(NSError **)error;

#pragma mark
#pragma mark Trace Data
- (void)dumpAttributes:(NSEntityDescription *)entityDescription forObject:(NSManagedObject *)originalObject;

#pragma mark -
#pragma mark Data Store Metatdata
- (void)setMetadata:(NSString *)stringValue forKey:(NSString *)key inStoreAtURL:(NSURL *)storeURL;
- (NSString *)metadataForKey:(NSString *)key inStoreAtURL:(NSURL *)storeURL;
+ (NSString *)metadataForKey:(NSString *)key inStoreAtURL:(NSURL *)storeURL;

@end
