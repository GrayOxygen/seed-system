//
//  EnhancedTrigger.h
//  MSCommandsManager
//
//  Created by Paul Herzog on 5/11/10.
//  Copyright 2010 Nuance Communications, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class TriggerPhrase;
@class TriggerMO;

@interface EnhancedTrigger : NSObject {
    NSMutableArray *orderedPhrases;
}

#pragma mark -
#pragma mark Properties
@property(retain) NSMutableArray *orderedPhrases;

#pragma mark -
#pragma mark Initialization
- (id)initWithTriggerText:(NSString *)triggerText;
- (id)initWithAttributedText:(NSAttributedString *)attributedText;
- (id)initWithEscapedText:(NSString *)escapedText;

#pragma mark -
#pragma mark Identify and Compare
- (NSString *)description;
- (NSUInteger)hash;
- (BOOL)isEqual:(id)other;

#pragma mark -
#pragma mark Adding and Removing Phrases
- (void)addPhrase:(TriggerPhrase *)phrase;
- (void)insertPhrase:(TriggerPhrase *)phrase atIndex:(NSUInteger)index;
- (void)removeAllPhrases;
- (void)removePhraseAtIndex:(NSUInteger)index;
- (void)replacePhraseAtIndex:(NSUInteger)index withPhrase:(TriggerPhrase *)phrase;

#pragma mark -
#pragma mark Phrase Accessors
- (TriggerPhrase *)phraseAtIndex:(NSUInteger)index;
- (NSArray *)phrases;
- (NSUInteger)count;
- (NSString *)triggerText;

- (NSAttributedString *)triggerAttributedText;
- (NSAttributedString *)triggerAttributedTextWithFontInfo:(NSDictionary *)fontInfo;
- (NSString *)escapedTriggerText;

@end
