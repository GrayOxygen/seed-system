//
//  MSApplicationInfo.h
//  MSCommandsManager
//
//  Created by Paul Herzog on 8/11/09.
//  Copyright 2009 MacSpeech, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface MSApplicationInfo : NSObject {
    NSString *type;
    NSNumber *appVersion;
    NSString *appBundle;
    NSString *displayName;
}

#pragma mark -
#pragma mark Initialization
- (id)initAppForBundle:(NSString *)bundleID version:(NSNumber *)version;
- (id)initAppForContextBundle:(NSString *)bundleID version:(NSNumber *)version;

#pragma mark -
#pragma mark Accessors
- (NSString *)type;
- (void)setType:(NSString *)value;

- (NSNumber *)appVersion;
- (void)setAppVersion:(NSNumber *)value;

- (NSString *)appBundle;
- (void)setAppBundle:(NSString *)value;

- (NSString *)displayName;


#pragma mark -
#pragma mark Comparisons
- (BOOL)isIdenticalTo:(MSApplicationInfo *)otherInfo;
- (BOOL)isGlobal;
- (BOOL)isApplication;

@end
