//
//  NSManagedObjectModel+Utilities.h
//  MSCommandsManager
//
//  Created by Paul Herzog on 23-Jul-2007.
//  Copyright 2007 MacSpeech, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface NSManagedObjectModel (Utilities)

#pragma mark
#pragma mark Debugging
- (void)logAllEntities;
- (NSString *)stringOfEntity:(NSEntityDescription *)entityDescription;
- (NSString *)stringOfAttributesForEntity:(NSEntityDescription *)entityDescription;
- (NSString *)stringOfRelationshipsForEntity:(NSEntityDescription *)entityDescription;
- (NSEntityDescription *)entityNamed:(NSString *)name;

@end
