//
//  BookmarkAlias.h
//  CommandsManager
//
//  Created by Paul Herzog on 3-May-2013
//  Copyright (c) 2013 Nuance Communications, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BookmarkAlias : NSObject

+ (NSURL *)urlForAliasData:(NSData *)data;
+ (NSString *)fullPathForAliasData:(NSData *)aliasData;
+ (NSData *)aliasDataForPath:(NSString *)path;

@end
