//
//  MSCommandsManager+Workspace.h
//  MSCommandsManager
//
//  Created by Paul Herzog on 17-Sep-2007.
//  Copyright 2007 MacSpeech, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface MSCommandsManager(Workspace)

#pragma mark
#pragma mark Active Application
- (void *)installAppChangedEventHandler;
- (void)inspectFrontApp;
- (void)notifyActivationForAppAtPath:(NSString *)fullAppPath;

#pragma mark
#pragma mark Accessors
- (NSString *)activeAppBundleID;
- (void)setActiveAppBundleID:(NSString *)appBundleID;

- (NSString *)activeAppName;
- (void)setActiveAppName:(NSString *)appName;

- (NSString *)activeAppShortVersion;
- (void)setActiveAppShortVersion:(NSString *)appShortVersion;

- (NSInteger)activeAppMajorVersion;
- (void)setActiveAppMajorVersion:(NSInteger)appMajorVersion;


#pragma mark
#pragma mark Notifications Support
- (void)postApplicationActivatedNotification;

@end
