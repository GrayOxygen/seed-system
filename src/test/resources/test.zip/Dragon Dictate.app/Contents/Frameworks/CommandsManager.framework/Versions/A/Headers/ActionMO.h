//
//  ActionMO.h
//
//  Created by Paul Herzog
//  Copyright 2007 MacSpeech, Inc. All rights reserved.
//
#import "_ActionMO.h"

@interface ActionMO : _ActionMO {}

#pragma mark
#pragma mark Accessors
- (NSAttributedString *)displayText;
- (void)setDisplayText:(NSAttributedString *)attributedText;
- (NSString *)languageText;
//- (NSArray *)guiActionLines;
//- (void)setGuiActionLines:(NSArray *)lines;
- (BOOL)isEditable;
- (NSString *)importFriendlyText;
+ (NSString *)replaceClassTermsWithPropertyTermsIn:(NSString *)applescriptText;

#pragma mark
#pragma mark Support
- (NSAttributedString *)attributedTextForAppleScript;
- (BOOL)compileAppleScript;
- (NSDictionary *)hiddenOptions;

#pragma mark
#pragma mark Execute Dispatcher
- (BOOL)execute;
- (BOOL)executeWithVariables:(NSDictionary *)variables;

#pragma mark -
#pragma mark Execute Notifications
- (void)notifyCommandExecutionStarted;
- (void)notifyCommandExecutionFinished;

#pragma mark
#pragma mark Execute Actions
- (BOOL)executeAppleScriptWithVariables:(NSDictionary *)variables;
- (BOOL)executeTextPasteWithVariables:(NSDictionary *)variables;
- (BOOL)executeKeystrokeWithVariables:(NSDictionary *)variables;
- (BOOL)executeOpenAliasWithVariables:(NSDictionary *)variables;
- (BOOL)executeOpenURLWithVariables:(NSDictionary *)variables;
- (BOOL)executeLaunchApplicationWithVariables:(NSDictionary *)variables;


#pragma mark -
#pragma mark Keystroke Support
- (NSMutableArray *)keystrokes;
- (void)setKeystrokes:(NSMutableArray *)keystrokeItems;

#pragma mark -
#pragma mark ShellScript Support
- (NSNumber *)openInTerminal;
- (void)setOpenInTerminal:(NSNumber *)openInTerminal;
- (BOOL)executeShellScriptWithVariables:(NSDictionary *)variables;
- (BOOL)didLaunchShellScript:(NSString *)shellScript;
- (BOOL)didLaunchShellScriptInWindow:(NSString *)shellScript;
- (NSString *)tempFileName;

@end
