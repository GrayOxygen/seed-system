// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to CommandMO.h instead.

#import <CoreData/CoreData.h>
#import "MSMOBase.h"

@class TriggerMO;
@class TriggerMO;
@class LocationMO;
@class ActionMO;
@class ActionMO;
@class ActionMO;
@class TriggerMO;

@interface CommandMOID : NSManagedObjectID {}
@end

@interface _CommandMO : MSMOBase {}
+ (id)newInManagedObjectContext:(NSManagedObjectContext*)moc_;
- (CommandMOID*)objectID;



- (NSNumber*)isSpelling;
- (void)setIsSpelling:(NSNumber*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSNumber *isSpelling;
#endif

- (BOOL)isSpellingValue;
- (void)setIsSpellingValue:(BOOL)value_;

//- (BOOL)validateIsSpelling:(id*)value_ error:(NSError**)error_;



- (NSNumber*)active;
- (void)setActive:(NSNumber*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSNumber *active;
#endif

- (BOOL)activeValue;
- (void)setActiveValue:(BOOL)value_;

//- (BOOL)validateActive:(id*)value_ error:(NSError**)error_;



- (NSString*)triggerString;
- (void)setTriggerString:(NSString*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSString *triggerString;
#endif

//- (BOOL)validateTriggerString:(id*)value_ error:(NSError**)error_;



- (NSNumber*)display;
- (void)setDisplay:(NSNumber*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSNumber *display;
#endif

- (BOOL)displayValue;
- (void)setDisplayValue:(BOOL)value_;

//- (BOOL)validateDisplay:(id*)value_ error:(NSError**)error_;



- (NSNumber*)isUser;
- (void)setIsUser:(NSNumber*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSNumber *isUser;
#endif

- (BOOL)isUserValue;
- (void)setIsUserValue:(BOOL)value_;

//- (BOOL)validateIsUser:(id*)value_ error:(NSError**)error_;



- (NSString*)type;
- (void)setType:(NSString*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSString *type;
#endif

//- (BOOL)validateType:(id*)value_ error:(NSError**)error_;



- (NSString*)altActionContent;
- (void)setAltActionContent:(NSString*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSString *altActionContent;
#endif

//- (BOOL)validateAltActionContent:(id*)value_ error:(NSError**)error_;



- (NSString*)osLanguage;
- (void)setOsLanguage:(NSString*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSString *osLanguage;
#endif

//- (BOOL)validateOsLanguage:(id*)value_ error:(NSError**)error_;



- (NSNumber*)commandID;
- (void)setCommandID:(NSNumber*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSNumber *commandID;
#endif

- (NSInteger)commandIDValue;
- (void)setCommandIDValue:(NSInteger)value_;

//- (BOOL)validateCommandID:(id*)value_ error:(NSError**)error_;



- (NSString*)appBundle;
- (void)setAppBundle:(NSString*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSString *appBundle;
#endif

//- (BOOL)validateAppBundle:(id*)value_ error:(NSError**)error_;



- (NSNumber*)isDictation;
- (void)setIsDictation:(NSNumber*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSNumber *isDictation;
#endif

- (BOOL)isDictationValue;
- (void)setIsDictationValue:(BOOL)value_;

//- (BOOL)validateIsDictation:(id*)value_ error:(NSError**)error_;



- (NSString*)spokenLanguage;
- (void)setSpokenLanguage:(NSString*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSString *spokenLanguage;
#endif

//- (BOOL)validateSpokenLanguage:(id*)value_ error:(NSError**)error_;



- (NSNumber*)isCommand;
- (void)setIsCommand:(NSNumber*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSNumber *isCommand;
#endif

- (BOOL)isCommandValue;
- (void)setIsCommandValue:(BOOL)value_;

//- (BOOL)validateIsCommand:(id*)value_ error:(NSError**)error_;



- (NSNumber*)appVersion;
- (void)setAppVersion:(NSNumber*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSNumber *appVersion;
#endif

- (NSInteger)appVersionValue;
- (void)setAppVersionValue:(NSInteger)value_;

//- (BOOL)validateAppVersion:(id*)value_ error:(NSError**)error_;



- (NSNumber*)isCorrection;
- (void)setIsCorrection:(NSNumber*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSNumber *isCorrection;
#endif

- (BOOL)isCorrectionValue;
- (void)setIsCorrectionValue:(BOOL)value_;

//- (BOOL)validateIsCorrection:(id*)value_ error:(NSError**)error_;



- (NSString*)altTriggerString;
- (void)setAltTriggerString:(NSString*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSString *altTriggerString;
#endif

//- (BOOL)validateAltTriggerString:(id*)value_ error:(NSError**)error_;



- (NSNumber*)version;
- (void)setVersion:(NSNumber*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSNumber *version;
#endif

- (NSInteger)versionValue;
- (void)setVersionValue:(NSInteger)value_;

//- (BOOL)validateVersion:(id*)value_ error:(NSError**)error_;



- (NSString*)actionContent;
- (void)setActionContent:(NSString*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSString *actionContent;
#endif

//- (BOOL)validateActionContent:(id*)value_ error:(NSError**)error_;



- (NSString*)altTriggerDescription;
- (void)setAltTriggerDescription:(NSString*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSString *altTriggerDescription;
#endif

//- (BOOL)validateAltTriggerDescription:(id*)value_ error:(NSError**)error_;



- (NSString*)vendor;
- (void)setVendor:(NSString*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSString *vendor;
#endif

//- (BOOL)validateVendor:(id*)value_ error:(NSError**)error_;



- (NSNumber*)isSleep;
- (void)setIsSleep:(NSNumber*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSNumber *isSleep;
#endif

- (BOOL)isSleepValue;
- (void)setIsSleepValue:(BOOL)value_;

//- (BOOL)validateIsSleep:(id*)value_ error:(NSError**)error_;



- (NSString*)triggerDescription;
- (void)setTriggerDescription:(NSString*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSString *triggerDescription;
#endif

//- (BOOL)validateTriggerDescription:(id*)value_ error:(NSError**)error_;



- (NSNumber*)engineID;
- (void)setEngineID:(NSNumber*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSNumber *engineID;
#endif

- (NSInteger)engineIDValue;
- (void)setEngineIDValue:(NSInteger)value_;

//- (BOOL)validateEngineID:(id*)value_ error:(NSError**)error_;




- (TriggerMO*)altTrigger;
- (void)setAltTrigger:(TriggerMO*)value_;
//- (BOOL)validateAltTrigger:(id*)value_ error:(NSError**)error_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) TriggerMO* altTrigger;
#endif



- (NSSet*)trigger;
- (void)addTrigger:(NSSet*)value_;
- (void)removeTrigger:(NSSet*)value_;
- (void)addTriggerObject:(TriggerMO*)value_;
- (void)removeTriggerObject:(TriggerMO*)value_;
- (NSMutableSet*)triggerSet;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSSet* trigger;
#endif



- (LocationMO*)location;
- (void)setLocation:(LocationMO*)value_;
//- (BOOL)validateLocation:(id*)value_ error:(NSError**)error_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) LocationMO* location;
#endif



- (ActionMO*)currentAction;
- (void)setCurrentAction:(ActionMO*)value_;
//- (BOOL)validateCurrentAction:(id*)value_ error:(NSError**)error_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) ActionMO* currentAction;
#endif



- (ActionMO*)altAction;
- (void)setAltAction:(ActionMO*)value_;
//- (BOOL)validateAltAction:(id*)value_ error:(NSError**)error_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) ActionMO* altAction;
#endif



- (NSSet*)action;
- (void)addAction:(NSSet*)value_;
- (void)removeAction:(NSSet*)value_;
- (void)addActionObject:(ActionMO*)value_;
- (void)removeActionObject:(ActionMO*)value_;
- (NSMutableSet*)actionSet;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSSet* action;
#endif



- (TriggerMO*)currentTrigger;
- (void)setCurrentTrigger:(TriggerMO*)value_;
//- (BOOL)validateCurrentTrigger:(id*)value_ error:(NSError**)error_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) TriggerMO* currentTrigger;
#endif


@end
