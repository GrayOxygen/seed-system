// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to SpecificTermMO.h instead.

#import <CoreData/CoreData.h>
#import "MSMOBase.h"

@class GeneralTermMO;

@interface SpecificTermMOID : NSManagedObjectID {}
@end

@interface _SpecificTermMO : MSMOBase {}
+ (id)insertInManagedObjectContext:(NSManagedObjectContext*)moc_;
+ (NSString*)entityName;
+ (NSEntityDescription*)entityInManagedObjectContext:(NSManagedObjectContext*)moc_;
- (SpecificTermMOID*)objectID;



@property (nonatomic, retain) NSNumber *numericValue;

@property NSInteger numericValueValue;
- (NSInteger)numericValueValue;
- (void)setNumericValueValue:(NSInteger)value_;

//- (BOOL)validateNumericValue:(id*)value_ error:(NSError**)error_;



@property (nonatomic, retain) NSString *name;

//- (BOOL)validateName:(id*)value_ error:(NSError**)error_;




@property (nonatomic, retain) GeneralTermMO* generalTerm;
//- (BOOL)validateGeneralTerm:(id*)value_ error:(NSError**)error_;



@end

@interface _SpecificTermMO (CoreDataGeneratedAccessors)

@end
