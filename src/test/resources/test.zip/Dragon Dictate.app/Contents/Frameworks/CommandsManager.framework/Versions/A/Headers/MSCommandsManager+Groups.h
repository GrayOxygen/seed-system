//
//  MSCommandsManager+Groups.h
//  MSCommandsManager
//
//  Created by Paul Herzog on 13-Aug-2007.
//  Copyright 2007 MacSpeech, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>
@class MSCommandContext;
//@class AXObserverProxy;
//@class AXElementProxy;
@class PFApplicationUIElement;
@class PFUIElement;
@class PFObserver;

// Types of command groups
typedef enum {
   kMSCommandGroupTypeGlobal,
   kMSCommandGroupTypeCommandMode,
   kMSCommandGroupTypeCorrectionMode,
   kMSCommandGroupTypeDictationMode,
   kMSCommandGroupTypeSleepMode,
   kMSCommandGroupTypeSpellingMode,
   kMSCommandGroupTypeApplication,
   kMSCommandGroupTypeAppleScript,
   kMSCommandGroupTypeFile,
   kMSCommandGroupTypeShellScript,
   kMSCommandGroupTypeText,
   kMSCommandGroupTypeURL,
   kMSCommandGroupTypeWorkflow,
   kMSCommandGroupTypeVendor,
   kMSCommandGroupTypeAppBundle
} MSCommandGroupType;

extern NSString *MSCommandGroupFlattened;
extern NSString *MSCommandGroupGlobalsFirst;
extern NSString *MSCommandGroupSingleGlobalGroup;
extern NSString *MSCommandGroupShowUsageNotes;
extern NSString *MSCommandGroupSpecificLanguage;
extern NSString *MSCommandGroupHideAllGroupsForContext;
extern NSString *MSCommandGroupShowUsageNoteWithKey;
extern NSString *MSCommandGroupHiddenGroupList;
extern NSString *MSCommandShowAllApps;

@interface MSCommandsManager(Groups)


#pragma mark -
#pragma mark Initialization
- (NSDictionary *)initCommandGroups;

#pragma mark -
#pragma mark Simple Command Groups
- (NSString *)frontmostGroupName;
- (NSString *)frontmostBundleID;
- (NSArray *)orderedCommandsByTrigger:(NSArray *)unorderedCommands;
- (NSArray *)commandsInGroup:(MSCommandGroupType)groupType error:(NSError **)error;
- (NSArray *)commandsForVendor:(NSString *)vendor;
- (NSArray *)commandsForAppBundle:(NSString *)appBundle;
- (NSArray *)commandsForAppBundle:(NSString *)appBundle version:(NSNumber *)appVersion;
- (NSArray *)commandsInGroup:(MSCommandGroupType)groupType forVendor:(NSString *)vendor error:(NSError **)error;
- (NSArray *)commandsInGroup:(MSCommandGroupType)groupType forAppBundle:(NSString *)appBundle error:(NSError **)error;
- (NSArray *)commandsInGroup:(MSCommandGroupType)groupType forAppBundle:(NSString *)appBundle version:(NSNumber *)appVersion error:(NSError **)error;
- (NSArray *)filterCommands:(NSArray *)commands withMinNameLength:(NSInteger)minLength;
- (NSArray *)filterCommands:(NSArray *)commands withMaxVersion:(NSInteger)maxVersion;
- (void)setActive:(BOOL)active forAllVersionsOfCommands:(NSArray *)commands;
- (void)setActive:(BOOL)active forCommands:(NSArray *)commands;

#pragma mark -
#pragma mark Web ContextBundles
- (NSArray *)webContextGroupsSupportedByApp:(NSString *)bundleIdentifier;
- (NSArray *)commandsFromGroups:(NSArray *)groupList;

- (PFApplicationUIElement *)uiAppForFrontmostBundleID:(NSString *)bundleIdentifier;

- (BOOL)isWatchingWebContextApp;
- (BOOL)isWebContextSupportProvidedByBundle:(NSString *)bundleIdentifier;
- (void)setupWebContextNotificationsForBundleID:(NSString *)bundleIdentifier;
- (BOOL)didTeardownWebContextNotifications;

#pragma mark -
#pragma mark Browser Changed Callback 
//- (void)browserChangedForObserver:(AXObserverProxy *)observerProxy element:(AXElementProxy *)elementProxy notification:(CFStringRef)notification refCon:(void *)refCon;
- (void)browserChangedForPFObserver:(PFObserver *)observer notification:(NSString *)notification element:(PFUIElement *)element contextInfo:(void *)contextInfo;
- (void)notifyForAppPath:(NSString *)fullAppPath;

#pragma mark -
#pragma mark Command Groups
- (MSCommandGroup *)allGlobals;
- (MSCommandGroup *)groupForBundleIdentifier:(NSString *)bundleIdentifier;
- (NSNumber *)availableVersionForBundleIdentifier:(NSString *)bundleIdentifier;
- (NSArray *)sourceGroupsWithOptions:(NSDictionary *)options;
- (NSArray *)groupsForContext:(MSCommandContext *)context options:(NSDictionary *)options;

- (NSArray *)globalUsageNotes;
- (NSArray *)topLevelUsageNotes;
- (void)addUsageNotes:(NSArray *)notes asSubGroupsTo:(MSCommandGroup *)group;

- (void)addUsageNotesAsSubGroupsTo:(MSCommandGroup *)group;
- (NSArray *)addUsageNotesToGroupList:(NSArray *)groupList;
- (NSArray *)usageNotesWithKey:(NSString *)noteKey;
- (NSArray *)categorizeGlobals:(MSCommandGroup *)globalGroup singleGlobalGroup:(BOOL)singleGlobalGroup;

- (NSArray *)filterGroups:(NSArray *)commandGroups withTriggerTextLike:(NSString *)triggerText;
- (NSArray *)filterCommands:(NSArray *)commands withTriggerTextLike:(NSString *)triggerText;
- (NSDictionary *)globalSubGroupsForCommands:(NSArray *)commandList hiddingGroups:(NSArray *)hiddenGroupsList;
@end
