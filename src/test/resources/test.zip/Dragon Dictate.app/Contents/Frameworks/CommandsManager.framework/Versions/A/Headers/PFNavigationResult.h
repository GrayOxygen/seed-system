//
//  PFNavigationResult.h
//  CommandsManager
//
//  Created by Paul Herzog on 12/27/11.
//  Copyright (c) 2011 N/A. All rights reserved.
//

#import <Foundation/Foundation.h>

@class PFUIElement;

@interface PFNavigationResult : NSObject {
    PFUIElement *uiElement;
    NSString *attributeName;
}

@property(retain) PFUIElement *uiElement;
@property(retain) NSString *attributeName;

- (id)initWithElement:(PFUIElement *)navElement attributeName:(NSString *)navAttribute;

@end
