//
//  PFUtil.h
//  CommandsManager
//
//  Created by Paul Herzog on 12/28/11.
//  Copyright (c) 2011 N/A. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PFUtil : NSObject

#pragma mark -
#pragma mark Convenience Names
+ (NSString *)axAttributeForText:(NSString *)attributeText;
+ (NSString *)textForAXAttribute:(NSString *)axAttribute; // need this?
+ (NSDictionary *)attributesIndexedByText;

+ (NSString *)axRoleForText:(NSString *)elementText;
+ (NSString *)textForAXRole:(NSString *)axRole;
+ (NSDictionary *)rolesIndexedByText;

+ (NSString *)axSubroleForText:(NSString *)elementText;
+ (NSString *)textForAXSubrole:(NSString *)axSubrole;
+ (NSDictionary *)subrolesIndexedByText;

@end
