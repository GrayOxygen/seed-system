//
//  ScriptConversion.h
//  MSCommandsManager
//
//  Created by Paul Herzog on 5/30/08.
//  Copyright 2008 MacSpeech, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface ScriptConversion : NSObject {

}
#pragma mark -
#pragma mark Converts AppleScript to MenuItem specs
+ (BOOL)canBeConvertedToMenuItem:(NSString *)textString;
+ (NSString *)convertToMenuItem:(NSString *)textString;

#pragma mark -
#pragma mark Converts Key Code to Keystroke in AppleScript
+ (NSRange)keyCodeRangeConvertableToKeystroke:(NSString *)textString;
+ (NSString *)convertToKeystroke:(NSString *)textString;
+ (NSString *)keystrokePhraseForKeyCodePhrase:(NSString *)text;
@end
