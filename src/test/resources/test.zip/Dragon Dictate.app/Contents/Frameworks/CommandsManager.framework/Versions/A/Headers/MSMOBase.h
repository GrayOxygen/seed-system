//
//  MSMOBase.h
//  MSCommandsManager
//
//  Created by Paul Herzog on 19-Jul-2007.
//  Copyright 2007 MacSpeech, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class InfoMO;

@interface MSMOBase : NSManagedObject {

}

#pragma mark
#pragma mark Abstract Representation
- (NSString *)abstractRepresentation;
- (NSSet *)attributesForRepresentation;
- (BOOL)isEqualToRepresentationOf:(MSMOBase *)otherObject;
+ (NSMutableSet *)representationsForObjectsInSet:(NSSet *)set;
- (NSString *)objectDesc;

#pragma mark -
#pragma mark Info objects related to an entity
- (InfoMO *)infoObject;
- (NSManagedObjectContext *)mocForInfo;
- (NSString *)objectIDText;
- (NSDictionary *)options;
- (void)setOptions:(NSDictionary *)options;

@end
