//
//  ActionMO+MenuItem.h
//  MSCommandsManager
//
//  Created by Paul Herzog on 5/26/10.
//  Copyright 2010 Nuance Communications, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "ActionMO.h"

@class PFApplicationUIElement;
@class PFUIElement;

@interface ActionMO(MenuItem)

#pragma mark -
#pragma mark MenuItem Execution
- (BOOL)executeMenuItemWithVariables:(NSDictionary *)variables;

- (void)clickMenuItem:(NSDictionary *)menuInfo withUIApp:(PFApplicationUIElement *)uiApp;
- (PFUIElement *)menuItemNamed:(NSString *)menuName fromMenuElements:menuList;

- (NSString *)textFromAnnotatedMenuPath:(NSString *)menuPath;
- (NSString *)annotationFromMenuItemText:(NSString *)menuItemText;
- (void)alertUnavailableComponent:(NSString *)menuComponent ofMenuPath:(NSString *)menuPath;
- (void)alertAlreadyCheckedMenuPath:(NSString *)menuPath;
- (void)alertAlreadyUncheckedMenuPath:(NSString *)menuPath;
- (void)alertDisabledMenuPath:(NSString *)menuPath;
- (void)alertMenuItemFailureMessage:(NSString *)message withTitle:(NSString *)title;
- (void)alertMenuItemFailureMessage:(NSString *)message;

@end
