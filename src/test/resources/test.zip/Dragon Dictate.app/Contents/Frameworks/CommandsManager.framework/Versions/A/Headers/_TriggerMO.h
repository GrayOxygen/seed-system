// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to TriggerMO.h instead.

#import <CoreData/CoreData.h>
#import "MSMOBase.h"

@class CommandMO;
@class CommandMO;
@class CommandMO;

@interface TriggerMOID : NSManagedObjectID {}
@end

@interface _TriggerMO : MSMOBase {}
+ (id)newInManagedObjectContext:(NSManagedObjectContext*)moc_;
- (TriggerMOID*)objectID;



- (NSString*)desc;
- (void)setDesc:(NSString*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSString *desc;
#endif

//- (BOOL)validateDesc:(id*)value_ error:(NSError**)error_;



- (NSNumber*)isUser;
- (void)setIsUser:(NSNumber*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSNumber *isUser;
#endif

- (BOOL)isUserValue;
- (void)setIsUserValue:(BOOL)value_;

//- (BOOL)validateIsUser:(id*)value_ error:(NSError**)error_;



- (NSString*)string;
- (void)setString:(NSString*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSString *string;
#endif

//- (BOOL)validateString:(id*)value_ error:(NSError**)error_;



- (NSString*)spokenLanguage;
- (void)setSpokenLanguage:(NSString*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSString *spokenLanguage;
#endif

//- (BOOL)validateSpokenLanguage:(id*)value_ error:(NSError**)error_;




- (CommandMO*)currentCommand;
- (void)setCurrentCommand:(CommandMO*)value_;
//- (BOOL)validateCurrentCommand:(id*)value_ error:(NSError**)error_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) CommandMO* currentCommand;
#endif



- (CommandMO*)altCommand;
- (void)setAltCommand:(CommandMO*)value_;
//- (BOOL)validateAltCommand:(id*)value_ error:(NSError**)error_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) CommandMO* altCommand;
#endif



- (CommandMO*)command;
- (void)setCommand:(CommandMO*)value_;
//- (BOOL)validateCommand:(id*)value_ error:(NSError**)error_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) CommandMO* command;
#endif


@end
