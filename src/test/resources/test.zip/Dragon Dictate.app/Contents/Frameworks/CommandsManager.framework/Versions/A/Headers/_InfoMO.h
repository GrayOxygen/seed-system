// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to InfoMO.h instead.

#import <CoreData/CoreData.h>
#import "MSMOBase.h"


@interface InfoMOID : NSManagedObjectID {}
@end

@interface _InfoMO : MSMOBase {}
+ (id)insertInManagedObjectContext:(NSManagedObjectContext*)moc_;
+ (NSString*)entityName;
+ (NSEntityDescription*)entityInManagedObjectContext:(NSManagedObjectContext*)moc_;
- (InfoMOID*)objectID;



@property (nonatomic, retain) NSData *data;

//- (BOOL)validateData:(id*)value_ error:(NSError**)error_;



@property (nonatomic, retain) NSString *entityID;

//- (BOOL)validateEntityID:(id*)value_ error:(NSError**)error_;




@end

@interface _InfoMO (CoreDataGeneratedAccessors)

@end
