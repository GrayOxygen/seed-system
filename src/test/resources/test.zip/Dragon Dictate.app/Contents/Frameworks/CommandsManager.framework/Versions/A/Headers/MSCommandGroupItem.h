//
//  MSCommandGroupItem.h
//  MSCommandsManager
//
//  Created by Paul Herzog on 11/8/08.
//  Copyright 2008 MacSpeech, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface MSCommandGroupItem : NSObject {
  NSString *itemText;
  NSString *itemDesc;
  id target;
  id refData;
}


#pragma mark -
#pragma mark Initialization
- (id)initWithText:(NSString *)text forTarget:(id)itemTarget withRefData:(id)itemRefData;

#pragma mark -
#pragma mark Accessors
- (NSString *)itemText;
- (void)setItemText:(NSString *)value;

- (id)target;
- (void)setTarget:(id)value;

- (id)refData;
- (void)setRefData:(id)value;

- (NSString *)itemDesc;
- (void)setItemDesc:(NSString *)value;

- (NSDictionary *)refDataAsDictionary;

- (NSComparisonResult)compareItemText:(MSCommandGroupItem *)otherItem;

@end
