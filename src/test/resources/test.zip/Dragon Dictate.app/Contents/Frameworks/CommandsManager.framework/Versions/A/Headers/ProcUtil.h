//
//  ProcUtil.h
//  CommandsManager
//
//  Created by Paul Herzog on 12/28/11.
//  Copyright (c) 2011 N/A. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ProcUtil : NSObject

+ (NSString *)appBundleIDForPid:(pid_t)pid;

@end
