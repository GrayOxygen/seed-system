//
//  CommandMO.h
//
//  Created by Paul Herzog
//  Copyright 2007 MacSpeech, Inc. All rights reserved.
//

#import "_CommandMO.h"

@class MSApplicationInfo;
@class EnhancedTrigger;

// Action Types
extern NSString * ALIAS_ACTION;
extern NSString * APPLESCRIPT_ACTION;
extern NSString * APPLICATION_ACTION;
extern NSString * SHELLSCRIPT_ACTION;
extern NSString * TEXT_ACTION;
extern NSString * URL_ACTION;
extern NSString * WORKFLOW_ACTION;
extern NSString * INTERNAL_ACTION;
extern NSString * UNSPECIFIED_ACTION;
extern NSString * MENUITEM_ACTION;
extern NSString * HIDDEN_ACTION;
extern NSString * GUI_ACTION;
extern NSString * KEYSTROKE_ACTION;

// UI AppleScript Commands
extern NSString *REVEAL_COMMAND;


typedef enum {
    MSCommandTypeAppleScript = 'asCT',
    MSCommandTypeText = 'txCT',
    MSCommandTypeFile = 'flCT',
    MSCommandTypeBookmark = 'bmCT',
    MSCommandTypeShellScript = 'ssCT',
    MSCommandTypeInternal = 'inCT',
    MSCommandTypeUnspecified = 'unCT',
    MSCommandTypeMenuItem = 'miCT',
    MSCommandTypeHidden = 'hiCT',
    MSCommandTypeGUI = 'guCT',
    MSCommandTypeKeystroke = 'ksCT'
} MSCommandType;

@interface CommandMO : _CommandMO {
   id container;
   BOOL useAltTrigger;
}

#pragma mark
#pragma mark Class Utilities
+ (NSPredicate *)predicateTemplateForSpecificCommands;
+ (void)setActionInvocation:(NSInvocation *)actionInvocation forCommandType:(NSString *)commandType;
+ (void)setScriptInvocation:(NSInvocation *)scriptInvocation forScriptCommandName:(NSString *)scriptCommandName;
+ (void)setKeystrokeHandler:(NSInvocation *)keystrokeHandler;
+ (NSInvocation *)keystrokeHandler;

#pragma mark
#pragma mark Utilities
- (NSDictionary *)loadCommandIdentifierDictionary:(NSMutableDictionary *)commandIdentifiers;
- (BOOL)isCustomUserCommand;
- (BOOL)isEditable;
- (NSString *)shortDescription;
- (NSArray *)actionLanguages;
- (NSString *)triggerInfo;
- (CommandMO *)cloneIntoManagedObjectContext:(NSManagedObjectContext *)managedObjectContext;
- (NSSet *)nonTransientAttributeNamesIgnoring:(NSSet *)ignoredAttributeNames;
- (BOOL)isEqualTo:(CommandMO *)otherCommand ignoringActive:(BOOL)ignoringActive;
- (BOOL)isEqualTo:(CommandMO *)otherCommand forLanguage:(NSString *)language ignoringActive:(BOOL)ignoringActive;
- (NSString *)commandPredicate;
- (void)cloneAndReplaceTrigger:(TriggerMO *)newTrigger;
- (void)cloneAndReplaceAction:(ActionMO *)newAction;

#pragma mark
#pragma mark Language Support
- (TriggerMO *)triggerForLanguage:(NSString *)language;
- (ActionMO *)actionForLanguage:(NSString *)language;
- (void)setAltLanguage:(NSString *)language;
- (void)setCurrentLanguage:(NSString *)language;
- (NSString *)viewableTriggerString;
- (void)setViewableTriggerString:(NSString *)text;
- (NSString *)displayableTriggerString;
- (NSString *)displayableTriggerDescription;
- (void)setDisplayableTriggerString:(NSString *)displayableString;
- (void)setDisplayableTriggerDescription:(NSString *)displayableDesc;
- (void)setUseAltTrigger:(BOOL)useAlt;
- (BOOL)useAltTrigger;
- (ActionMO *)insertActionForLanguage:(NSString *)language;
- (TriggerMO *)insertTriggerForLanguage:(NSString *)language;
- (NSSet *)spokenLanguages;
- (NSSet *)osLanguages;
- (BOOL)supportsAllSpokenLanguages:(NSSet *)languages;

#pragma mark
#pragma mark Accessors
- (NSColor *)originColor;
- (NSString *)origin;
- (NSImage *)originImage;
- (NSImage *)originImageForEditor;
- (NSAttributedString *)displayText;
- (void)setDisplayText:(NSAttributedString *)displayText;
- (NSArray *)allVersions:(NSError **)error;
- (void)setAllVersionsActive:(NSNumber*)active;
- (void)setAllVersionsActiveValue:(BOOL)active;
- (NSString *)commandKey;
- (NSString *)vendorIgnoredKey;
- (TriggerMO *)insertAltTriggerWithAction:(ActionMO *)originalAction forLanguage:(NSString *)language;
- (TriggerMO *)insertCurrentTriggerWithAction:(ActionMO *)originalAction forLanguage:(NSString *)language;
- (NSString *)filteredTriggerDescription;
- (void)setFilteredTriggerDescription:(NSString*)value_;
- (NSString *)filteredTriggerString;
- (void)setFilteredTriggerString:(NSString*)value_;
- (NSString *)triggerString;
- (void)setTriggerString:(NSString*)value_;
- (NSString *)pronunciationString;
- (void)setPronunciationString:(NSString*)value_;
- (NSString *)groupNameString;
- (void)setGroupNameString:(NSString*)value_;
- (EnhancedTrigger *)enhancedTriggerString;
- (void)setEnhancedTriggerString:(EnhancedTrigger *)value_;

#pragma mark -
#pragma mark Command Parameters and Execution
- (void)executeWithParameters:(NSDictionary *)parameters;

#pragma mark
#pragma mark Scripting Support
- (NSString *)appName;
- (void)initCommandTypeMap;
- (MSCommandType)commandType;
- (BOOL)hasContainer;
- (void)setContainer:(id)commandContainer;
+ (void)showSpecifier:(NSScriptObjectSpecifier *)specifier;
- (void)prepareForCommandExecution;
- (NSDictionary *)infoWithoutAccents:(NSDictionary *)accentedInfo;
- (id)executeCommand:(NSScriptCommand *)scriptCommand;
- (id)revealCommand:(NSScriptCommand *)scriptCommand;
- (id)invokeScriptCommand:(NSScriptCommand *)scriptCommand forScriptCommandName:(NSString *)scriptCommandName;
- (NSString *)launchScriptForHostApp:(NSString *)hostAppName;

#pragma mark
#pragma mark Generated Commands
+ (NSString *)userVendor;
+ (NSString *)generatedApplicationVendor;
+ (NSString *)generatedBookmarkVendor;
- (BOOL)isGlobalCommand;
- (BOOL)isGeneratedCommand;
- (BOOL)isGeneratedApplicationCommand;
- (BOOL)isGeneratedBookmarkCommand;
- (NSString *)generatedApplicationName;

- (BOOL)isInternalCommand;
- (BOOL)isHiddenCommand;
- (BOOL)isUnspecifiedCommand;
- (BOOL)isAppleScriptCommand;

+ (MSApplicationInfo *)globalApplicationInformation;
- (MSApplicationInfo *)applicationInformation;
- (void)setApplicationInformation:(MSApplicationInfo *)inApplicationInformation;

@end
