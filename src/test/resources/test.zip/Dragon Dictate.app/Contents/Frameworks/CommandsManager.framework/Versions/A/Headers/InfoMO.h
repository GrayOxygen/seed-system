#import "_InfoMO.h"

@interface InfoMO : _InfoMO {}

@end
