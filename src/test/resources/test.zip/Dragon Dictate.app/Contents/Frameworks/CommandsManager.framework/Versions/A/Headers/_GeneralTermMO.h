// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to GeneralTermMO.h instead.

#import <CoreData/CoreData.h>
#import "MSMOBase.h"

@class SpecificTermMO;

@interface GeneralTermMOID : NSManagedObjectID {}
@end

@interface _GeneralTermMO : MSMOBase {}
+ (id)insertInManagedObjectContext:(NSManagedObjectContext*)moc_;
+ (NSString*)entityName;
+ (NSEntityDescription*)entityInManagedObjectContext:(NSManagedObjectContext*)moc_;
- (GeneralTermMOID*)objectID;



@property (nonatomic, retain) NSString *termDesc;

//- (BOOL)validateTermDesc:(id*)value_ error:(NSError**)error_;



@property (nonatomic, retain) NSString *spokenLanguage;

//- (BOOL)validateSpokenLanguage:(id*)value_ error:(NSError**)error_;



@property (nonatomic, retain) NSString *name;

//- (BOOL)validateName:(id*)value_ error:(NSError**)error_;



@property (nonatomic, retain) NSString *termType;

//- (BOOL)validateTermType:(id*)value_ error:(NSError**)error_;



@property (nonatomic, retain) NSString *bundleIdentifier;

//- (BOOL)validateBundleIdentifier:(id*)value_ error:(NSError**)error_;



@property (nonatomic, retain) NSString *image16Path;

//- (BOOL)validateImage16Path:(id*)value_ error:(NSError**)error_;




@property (nonatomic, retain) NSSet* specificTerms;
- (NSMutableSet*)specificTermsSet;



@end

@interface _GeneralTermMO (CoreDataGeneratedAccessors)

- (void)addSpecificTerms:(NSSet*)value_;
- (void)removeSpecificTerms:(NSSet*)value_;
- (void)addSpecificTermsObject:(SpecificTermMO*)value_;
- (void)removeSpecificTermsObject:(SpecificTermMO*)value_;

@end
