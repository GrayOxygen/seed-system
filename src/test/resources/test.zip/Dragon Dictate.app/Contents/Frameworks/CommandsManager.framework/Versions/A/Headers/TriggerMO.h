//
//  TriggerMO.h
//
//  Created by Paul Herzog
//  Copyright 2007 MacSpeech, Inc. All rights reserved.
//

#import "_TriggerMO.h"

@class EnhancedTrigger;

@interface TriggerMO : _TriggerMO {}

#pragma mark
#pragma mark Bookmarks
- (NSString *)generatedBookmarkName;

#pragma mark
#pragma mark Accessors
- (BOOL)hasSpecialGroupName;
- (BOOL)hasSpecialPronunciation;

- (NSString *)updateGroupName:(NSString *)value_;
- (NSString *)updatePronunciation:(NSString *)value_;

- (NSString *)updateFilteredDescription:(NSString *)value_;
- (NSString *)updateFilteredString:(NSString *)value_;

+ (NSString *)filteredTriggerText:(NSString *)text;
+ (NSString *)filteredDescriptionText:(NSString *)text;

- (NSString *)filteredString;
- (void)setFilteredString:(NSString*)value_;

- (NSString *)filteredDesc;
- (void)setFilteredDesc:(NSString*)value_;

- (NSString *)pronunciation;
- (NSString *)groupName;

- (BOOL)isEditable;
- (NSString *)stringWithoutSpecificTerms;

#pragma mark -
#pragma mark Enhanced Triggers
- (EnhancedTrigger *)enhancedTrigger;
- (void)setEnhancedTrigger:(EnhancedTrigger *)enhancedTrigger;
- (NSAttributedString *)attributedTrigger;
- (void)setAttributedTrigger:(NSAttributedString *)attributedText;
    
#pragma mark -
#pragma mark Parameter Handling
- (BOOL)hasParameters;
- (NSDictionary *)defaultParameters;
@end
