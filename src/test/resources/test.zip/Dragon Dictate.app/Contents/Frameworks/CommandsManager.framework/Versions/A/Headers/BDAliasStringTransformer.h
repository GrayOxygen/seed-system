//
//  BDAliasStringTransformer.h
//  MSCommandsManager
//
//  Created by Paul Herzog on 2-Oct-2007.
//  Copyright 2007 MacSpeech, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface BDAliasStringTransformer : NSValueTransformer {

}

@end
