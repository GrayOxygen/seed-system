//
//  Keystroke.h
//  MSCommandsManager
//
//  Created by Paul Herzog on 9/6/10.
//  Copyright 2010 Nuance Communications, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#define kKeystrokeDataType @"KeystrokeDataType"

@interface Keystroke : NSObject {
    BOOL shiftModifier;
    BOOL controlModifier;
    BOOL optionModifier;
    BOOL commandModifier;
    char virtualKey;
    NSString *text;
}

@property(assign) BOOL shiftModifier;
@property(assign) BOOL controlModifier;
@property(assign) BOOL optionModifier;
@property(assign) BOOL commandModifier;
@property(assign) char virtualKey;
@property(retain) NSString *text;

- (NSString *)stringForVirtualKey:(char)key;
- (NSString *)uiRepresentation;
- (void)setUiRepresentation:(NSString *)representation;
- (NSString *)textRepresentation;

#pragma mark -
#pragma mark Key Utilities
+ (NSDictionary *)modifiers;
+ (NSDictionary *)virtualKeys;
+ (NSString *)nameForVirtualKey:(char)virtualKeyValue;

@end
