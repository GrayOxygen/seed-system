// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to LocationMO.h instead.

#import <CoreData/CoreData.h>
#import "MSMOBase.h"

@class CommandMO;

@interface LocationMOID : NSManagedObjectID {}
@end

@interface _LocationMO : MSMOBase {}
+ (id)newInManagedObjectContext:(NSManagedObjectContext*)moc_;
- (LocationMOID*)objectID;



- (NSString*)string;
- (void)setString:(NSString*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSString *string;
#endif

//- (BOOL)validateString:(id*)value_ error:(NSError**)error_;




- (NSSet*)commands;
- (void)addCommands:(NSSet*)value_;
- (void)removeCommands:(NSSet*)value_;
- (void)addCommandsObject:(CommandMO*)value_;
- (void)removeCommandsObject:(CommandMO*)value_;
- (NSMutableSet*)commandsSet;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSSet* commands;
#endif


@end
