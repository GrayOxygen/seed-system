//
//  MSBundleInfo.h
//  MSCommandsManager
//
//  Created by Paul Herzog on 3/7/08.
//  Copyright 2008 MacSpeech, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#define kMSApplicationVersionKey	(@"CFBundleShortVersionString")
#define kMSApplicationPathKey       (@"ApplicationPathKey")

@interface MSBundleInfo : NSObject {}

+(NSDictionary *)infoForApplication:(NSString *)appPath;
+(NSDictionary *)infoForBundleIdentifier:(NSString *)bundleIdentifier;
+ (BOOL)plistIsFromResourceForkForBundle:(NSBundle *)bundle;

#pragma mark -
#pragma mark Bundle Info
+ (NSString *)displayNameFromFullPath:(NSString *)fullAppPath;
+ (NSString *)appShortVersionFromBundleInfo:(NSDictionary *)bundleInfo;

#pragma mark -
#pragma mark Bundle Types
+ (BOOL)isContextBundle:(NSString *)bundleIdentifier;
+ (BOOL)isGlobalBundle:(NSString *)bundleIdentifier;
+ (BOOL)isApplicationBundle:(NSString *)bundleIdentifier;

#pragma mark -
#pragma mark Bundle Display Names
+ (NSString *)displayNameForBundleIdentifier:(NSString *)bundleIdentifier;
+ (NSString *)displayNameForGlobalBundle;
+ (NSString *)displayNameForContextBundle:(NSString *)bundleIdentifier;
+ (NSString *)displayNameForApplicationBundle:(NSString *)bundleIdentifier;
+ (NSString *)pathForApplicationBundle:(NSString *)bundleIdentifier;
@end
