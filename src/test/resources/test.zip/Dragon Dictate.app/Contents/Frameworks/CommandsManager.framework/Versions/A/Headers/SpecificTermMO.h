//
//  SpecificTermMO.h
//
//  Created by Paul Herzog
//  Copyright 2010 Nuance Communications, Inc. All rights reserved.
//
#import "_SpecificTermMO.h"

@interface SpecificTermMO : _SpecificTermMO {}
// Custom logic goes here.
@end
