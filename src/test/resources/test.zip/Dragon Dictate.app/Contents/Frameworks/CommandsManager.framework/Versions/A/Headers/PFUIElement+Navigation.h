//
//  PFUIElement+Navigation.h
//  CommandsManager
//
//  Created by Paul Herzog on 12/27/11.
//  Copyright (c) 2011 N/A. All rights reserved.
//

#import <PFAssistive/PFAssistive.h>

@class PFNavigationResult;

@interface PFUIElement(Navigation)

- (PFNavigationResult *)elementAtPath:(NSString *)path;
- (NSArray *)elementsWithRoleOrSubrole:(NSString *)desiredRole inArray:(NSArray *)children;
- (NSDictionary *)elementAndIndexFromItemToken:(NSString *)itemToken;

#pragma mark -
#pragma mark Child Element Access
- (PFUIElement *)elementWithTitlePrefix:(NSString *)elementIdentifier orIndex:(NSInteger)elementIndex inArray:(NSArray *)elementArray;
- (PFUIElement *)elementWithTitlePrefix:(NSString *)titlePrefix inArray:(NSArray *)elementArray;
- (NSInteger)adjustedValueForIndex:(NSInteger)index withItemCount:(NSInteger)itemCount;


@end
