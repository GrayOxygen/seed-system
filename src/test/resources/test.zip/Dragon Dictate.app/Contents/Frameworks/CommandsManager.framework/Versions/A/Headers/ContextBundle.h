//
//  ContextBundle.h
//  MSCommandsManager
//
//  Created by Paul Herzog on 8/8/10.
//  Copyright 2010 Nuance Communications, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface ContextBundle : NSObject {
    NSString *type;
    NSString *name;
    NSString *identifier;
    NSString *locale;
}

#pragma mark -
#pragma mark Properties
@property(retain) NSString *type;
@property(retain) NSString *name;
@property(retain) NSString *identifier;
@property(retain) NSString *locale;

#pragma mark -
#pragma mark Initialization
- (id)initWithBundleIdentifier:(NSString *)bundleIdentifier;
- (id)initWithType:(NSString *)contextType locale:(NSString *)contextLocale identifier:(NSString *)contextIdentifier name:(NSString *)contextName;
- (NSString *)stringRepresentation;

#pragma mark -
#pragma mark Convenience Methods
+ (ContextBundle *)contextBundleWithIdentifier:(NSString *)bundleIdentifier;

@end
