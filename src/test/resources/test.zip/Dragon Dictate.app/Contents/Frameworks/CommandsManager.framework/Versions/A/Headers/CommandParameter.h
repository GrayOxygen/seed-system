//
//  CommandParameter.h
//  MSCommandsManager
//
//  Created by Paul Herzog on 6/29/10.
//  Copyright 2010 Nuance Communications, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSString(Diacriticals)
- (NSString *)unaccentedString;
@end

@interface CommandParameter : NSObject {
	NSString *prefix;
	NSString *booleanPrefix;
	NSMutableDictionary *nameUsageCount;
}

#pragma mark -
#pragma mark Standard Naming
+ (NSString *)nameForText:(NSString *)phraseText;
- (NSString *)parameterNameForText:(NSString *)phraseText;
- (NSString *)parameterNameForBooleanText:(NSString *)phraseText;
- (NSString *)plainParameterNameForText:(NSString *)phraseText;
- (NSString *)parameterNameForText:(NSString *)phraseText usingPrefix:(NSString *)namePrefix;

@end
