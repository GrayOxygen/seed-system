//
//  MSCommandContext.h
//  MSCommandsManager
//
//  Created by Paul Herzog on 31-Aug-2007.
//  Copyright 2007 MacSpeech, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>


// Speech engine modes
typedef enum {
   kMSSpeechEngineModeCommand = 'SMcm',
   kMSSpeechEngineModeCorrection = 'SMcr',
   kMSSpeechEngineModeDictation = 'SMdt',
   kMSSpeechEngineModeSpelling = 'SMsp',
   //kMSSpeechEngineModeNumbers = 'SMnm',
   kMSSpeechEngineModeSleep = 'SMsl'
} MSSpeechEngineMode;


@interface MSCommandContext : NSObject {
   MSSpeechEngineMode speechEngineMode;
   NSString *appBundle;
   NSNumber *appVersion;
   NSString *appName;
}

#pragma mark
#pragma mark Actions
- (void)refreshAppName;

#pragma mark
#pragma mark Accessors
- (MSSpeechEngineMode)speechEngineMode;
- (void)setSpeechEngineMode:(MSSpeechEngineMode)mode;

- (NSString *)appBundle;
- (void)setAppBundle:(NSString *)bundle;

- (NSString *)appName;
- (void)setAppName:(NSString *)name;

- (NSNumber *)appVersion;
- (void)setAppVersion:(NSNumber *)version;

- (NSString *)textForSpeechEngineMode:(MSSpeechEngineMode)mode;
@end

