//
//  CommandExportOperation.h
//  MSCommandsManager
//
//  Created by Paul Herzog on 8/13/10.
//  Copyright 2010 Nuance Communications, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class GeneralTermMO;

@interface CommandExportOperation : NSObject {
    NSSet *selectedKeys;
    BOOL useOriginalVendor;
    NSString *language;
    NSString *storePath;
    NSString *storeType;
    NSError *exportError;
    NSMutableSet *exportedTerms;
}

#pragma mark -
#pragma mark Properties
@property(retain) NSSet *selectedKeys;
@property(assign) BOOL useOriginalVendor;
@property(retain) NSString *language;
@property(retain) NSString *storePath;
@property(retain) NSString *storeType;
@property(retain) NSError *exportError;
@property(retain) NSMutableSet *exportedTerms;

#pragma mark -
#pragma mark Exported Terms
- (void)addExportedTerm:(GeneralTermMO *)term;

@end
