//
//  MSCommandGroup.h
//  MSCommandsManager
//
//  Created by Paul Herzog on 17-Sep-2007.
//  Copyright 2007 MacSpeech, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class MSApplicationInfo;

// Types of active state for a group of commands
typedef enum {
   kMSCommandGroupActiveStateUnknown,
   kMSCommandGroupActiveStateInactive,
   kMSCommandGroupActiveStateActive,
   kMSCommandGroupActiveStateMixed
} MSCommandGroupActiveState;

typedef enum {
	kMSGroupTypeCommands,
	kMSGroupTypeNotes
} MSGroupType;

@interface MSCommandGroup : NSObject {
   NSString *name;
   MSCommandGroupActiveState activeState;
   NSMutableArray *commands;
   MSGroupType groupType;
   NSString *key;
   NSString *groupDescription;
   MSApplicationInfo *applicationInformation;
   NSMutableArray *subGroups;
   NSString *groupCategory;
   NSString *actionTypeFilter;
}
@property(readonly) NSUInteger commandCount;
@property(readonly) BOOL isUserContext;
 
#pragma mark
#pragma mark Initialization
- (id)initWithName:(NSString *)groupName commands:(NSArray *)groupCommands activeState:(MSCommandGroupActiveState)groupActiveState;
- (id)initWithName:(NSString *)groupName content:(NSArray *)groupContent key:groupKey description:(NSString *)description;
- (NSMutableArray *)visibleCommandsInList:(NSArray *)commandList;

#pragma mark
#pragma mark Accessors
- (void)addSubGroup:(MSCommandGroup *)subGroup;
- (BOOL)didRemoveSubGroupName:(NSString *)subGroupName;

- (NSString *)name;
- (void)setName:(NSString *)groupName;

- (MSCommandGroupActiveState)activeState;
- (void)setActiveState:(MSCommandGroupActiveState)groupActiveState;

- (NSArray *)subGroups;
- (NSArray *)commands;
- (NSArray *)allCommands;
- (NSArray *)allCommandsExcludingGroups:(NSArray *)excludedGroups;
- (void)setCommands:(NSArray *)groupCommands;
- (void)setContent:(NSArray *)groupContent;

- (MSGroupType)groupType;
- (void)setGroupType:(MSGroupType)value;

- (NSString *)key;
- (void)setKey:(NSString *)value;

- (NSString *)groupDescription;
- (void)setGroupDescription:(NSString *)value;

- (BOOL)isGeneratedCommandGroup;

- (NSString *)groupCategory;
- (void)setGroupCategory:(NSString *)value;

- (BOOL)hasGlobalGroupCategory;

- (NSString *)actionTypeFilter;
- (void)setActionTypeFilter:(NSString *)value;

- (void)addCommand:(CommandMO *)command;
- (BOOL)didRemoveCommand:(CommandMO *)command;


#pragma mark
#pragma mark Display Filter
- (NSDictionary *)commandsIndexedByTriggerFilteredBy:(SEL)commandFilter inTarget:(NSObject *)target;
+ (NSMutableArray *)displayableCommands:(NSArray *)commands;
- (NSString *)groupCategoryFromText:(NSString *)text;
- (NSString *)filteredDescriptionFromText:(NSString *)text;
    

- (NSUInteger)countOfCommands;
- (CommandMO *)objectInCommandsAtIndex:(NSUInteger)index;
- (NSObject *)itemAtIndex:(NSUInteger)index;
- (NSUInteger)numberOfItems;
- (NSUInteger)numberOfSubGroups;
- (BOOL)hasSubGroups;


- (MSApplicationInfo *)applicationInformation;
- (void)setApplicationInformation:(MSApplicationInfo *)appInfo;
- (NSString *)appBundle;
- (NSNumber *)appVersion;
+ (MSCommandGroup *)emptyGlobalGroupNamed:(NSString *)groupName;

@end
