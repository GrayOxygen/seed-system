// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to ActionMO.h instead.

#import <CoreData/CoreData.h>
#import "MSMOBase.h"

@class CommandMO;

@interface ActionMOID : NSManagedObjectID {}
@end

@interface _ActionMO : MSMOBase {}
+ (id)newInManagedObjectContext:(NSManagedObjectContext*)moc_;
- (ActionMOID*)objectID;



- (NSData*)data;
- (void)setData:(NSData*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSData *data;
#endif

//- (BOOL)validateData:(id*)value_ error:(NSError**)error_;



- (NSNumber*)isUser;
- (void)setIsUser:(NSNumber*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSNumber *isUser;
#endif

- (BOOL)isUserValue;
- (void)setIsUserValue:(BOOL)value_;

//- (BOOL)validateIsUser:(id*)value_ error:(NSError**)error_;





- (NSString*)osLanguage;
- (void)setOsLanguage:(NSString*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSString *osLanguage;
#endif

//- (BOOL)validateOsLanguage:(id*)value_ error:(NSError**)error_;



- (NSString*)text;
- (void)setText:(NSString*)value_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) NSString *text;
#endif

//- (BOOL)validateText:(id*)value_ error:(NSError**)error_;




- (CommandMO*)altCommand;
- (void)setAltCommand:(CommandMO*)value_;
//- (BOOL)validateAltCommand:(id*)value_ error:(NSError**)error_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) CommandMO* altCommand;
#endif



- (CommandMO*)command;
- (void)setCommand:(CommandMO*)value_;
//- (BOOL)validateCommand:(id*)value_ error:(NSError**)error_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) CommandMO* command;
#endif



- (CommandMO*)currentCommand;
- (void)setCurrentCommand:(CommandMO*)value_;
//- (BOOL)validateCurrentCommand:(id*)value_ error:(NSError**)error_;
#if defined(MAC_OS_X_VERSION_10_5) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
@property (retain) CommandMO* currentCommand;
#endif


@end
