//
//  PFUIElement+Base.h
//  Dictate
//
//  Created by Paul Herzog on 12/27/11.
//  Copyright (c) 2011 N/A. All rights reserved.
//

#import <PFAssistive/PFAssistive.h>

@interface PFUIElement(Base)
- (BOOL)hasChildren;
- (NSString *)fallbackTitle;
- (BOOL)isSeparator;
- (BOOL)isMenu;

@end
