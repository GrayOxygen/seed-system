//
//  MSLocale.h
//  MSCommandsManager
//
//  Created by Paul Herzog on 18-Sep-2007.
//  Copyright 2007 MacSpeech, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface MSLocale : NSObject {
   NSLocale *locale;
}

#pragma mark
#pragma mark Initialization
- (id)initWithLocale:(NSLocale *)currentLocale;

#pragma mark
#pragma mark Accessors
- (NSString *)name;
- (NSString *)languageCode;
- (NSString *)countryCode;
- (NSString *)variant;
- (NSString *)masterLocale;

#pragma mark - 
#pragma mark Language Translation Support
+ (NSSet *)supportedLocaleIdentifiers;
+ (NSString *)masterLocaleForIdentifier:(NSString *)localeIdentifier;
+ (NSString *)baseLocaleIdentifier;
+ (NSString *)nameForLocaleIdentifier:(NSString *)localeIdentifier;
+ (NSString *)shortNameForLocaleIdentifier:(NSString *)localeIdentifier;
+ (NSLocale *)localeForLocaleIdentifier:(NSString *)localeIdentifier;
+ (NSLocale *)localeForName:(NSString *)name;
+ (NSArray *)sortedLanguageNames;

@end
