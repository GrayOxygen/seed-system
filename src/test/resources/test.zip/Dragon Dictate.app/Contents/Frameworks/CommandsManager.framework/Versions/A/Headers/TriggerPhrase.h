//
//  TriggerPhrase.h
//  MSCommandsManager
//
//  Created by Paul Herzog on 5/12/10.
//  Copyright 2010 Nuance Communications, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class EnhancedTrigger;

typedef enum {
    PhraseTypePlainText,
    PhraseTypeAlternative,
    PhraseTypeSynonym,
    PhraseTypeOptionalSynonym,
    PhraseTypeSpeech
} PhraseType;

extern NSString *TriggerTextFont;
extern NSString *TriggerAlternativeFont;
extern NSString *TriggerSynonymFont;
extern NSString *TriggerOptionalSynonymFont;
extern NSString *TriggerSpeechFont;

extern NSString *EscapeAlternativeStart;
extern NSString *EscapeAlternativeEnd;
extern NSString *EscapeSynonymStart;
extern NSString *EscapeSynonymEnd;
extern NSString *EscapeOptionalSynonymStart;
extern NSString *EscapeOptionalSynonymEnd;
extern NSString *EscapeSpeechStart;
extern NSString *EscapeSpeechEnd;

@interface TriggerPhrase : NSObject {
    PhraseType phraseType;
    NSString *phraseText;
}

#pragma mark -
#pragma mark Properties
@property(assign) PhraseType phraseType;
@property(retain) NSString *phraseText;

#pragma mark -
#pragma mark Initialization
- (id)initWithAttributedString:(NSAttributedString *)attributedText ;
- (id)initWithText:(NSString *)text;
- (id)initWithAlternativeName:(NSString *)listName;
- (id)initWithSynonymName:(NSString *)listName;
- (id)initWithOptionalSynonymName:(NSString *)listName;
- (id)initWithSpeech:(NSString *)text;

#pragma mark -
#pragma mark Identify and Compare
- (NSString *)description;
- (NSUInteger)hash;
- (BOOL)isEqual:(id)other;

#pragma mark -
#pragma mark Accessors
- (BOOL)isRequiredText;
- (BOOL)isAlternative;
- (BOOL)isSynonym;
- (BOOL)isOptionalSynonym;
- (BOOL)isSpeech;
- (BOOL)canHaveSpecificTerms;

#pragma mark -
#pragma mark Formatting Phrases
+ (NSString *)speechName;
+ (NSDictionary *)defaultFontInfo;
+ (NSAttributedString *)attributedWordBreakString;
+ (NSAttributedString *)attributedWordBreakStringWithFont:(NSFont *)font;
- (NSAttributedString *)attributedString;
- (NSAttributedString *)attributedStringWithFontInfo:(NSDictionary *)fontInfo;
+ (NSString *)descriptionForPhraseType:(PhraseType)phraseType;

#pragma mark -
#pragma mark Escaped Representation
- (NSString *)escapedPhraseText;

@end

