//
//  MSPane.h
//  Dictate
//
//  Created by Jacob Hazelgrove on 10/12/08.
//  Copyright © 2008, MacSpeech. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "MSMorphingView.h"

@interface MSPane : NSViewController {
	MSPane *_nextPane;
	MSPane *_previousPane;
	
	id _uiControl;
	
	NSString *_displayLabelString;
	NSView *_paneView;
	
	BOOL _creationMode;
	BOOL _usesCheckButtonLabel;
	
	CGFloat _indention;
	CGFloat _topPadding;
	
	BOOL _resizable;
	CGFloat _minimumHeight;
	
	id _controller;
	SEL _action;
}

@property (nonatomic, assign) MSPane *nextPane;
@property (nonatomic, assign) MSPane *previousPane;
@property (nonatomic, assign) NSView *paneView;
@property (nonatomic, assign) id controller;
@property (nonatomic) SEL action;
@property (nonatomic) BOOL creationMode;
@property (nonatomic) BOOL usesCheckButtonLabel;
@property (nonatomic, assign) IBOutlet id uiControl;
@property (nonatomic, copy) NSString *displayLabelString;
@property (nonatomic) CGFloat indention;
@property (nonatomic) CGFloat topPadding;
@property (nonatomic) BOOL resizable;
@property (nonatomic) CGFloat minimumHeight;
@property (readwrite, assign) NSString *toolTip;
@property (readwrite, assign) NSString *controlToolTip;

// Tool tip methods pass through to the _paneView
//- (void)setToolTip:(NSString *)toolTip;
//- (NSString *)toolTip;

- (NSString *)stringToAppendToLabel; // Subclassed to provide a string to be appended to the pane view's label when collapsed. Should ideally return a string describing the current value of the setting that the pane is editing. Default implementation returns an empty string.

- (id)uiControl;

- (void)handleSpaceBarPressed;		// Subclassed to handle the space bar being pressed when the pane view is key; this should be used for things like displaying an NSPopupButton's menu
/*
 - (void)handleLeftArrowKeyPressed;	// Subclassed to handle the left arrow key being pressed when the pane view is key; this should be used for things like moving selection of an NSSegmentedControl to the left
 - (void)handleRightArrowKeyPressed;	// Subclassed to handle the right arrow key being pressed when the pane view is key; this should be used for things like moving selection of an NSSegmentedControl to the right
*/
@end
