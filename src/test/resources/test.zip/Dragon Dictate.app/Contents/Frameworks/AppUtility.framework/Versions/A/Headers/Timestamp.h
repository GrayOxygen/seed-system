//
//  Timestamp.h
//  AppUtility
//
//  Created by Paul Herzog on 2/16/11.
//  Copyright 2011 Nuance Communications, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#define kTimeStringSize (32)

typedef enum {
	kTimeFormatFilename,
	kTimeFormatLogging,
	kTimeFormatProfile
} TimeFormat;


@interface Timestamp : NSObject {

}
+ (const char *)timeStamp;
+ (time_t)launchTime;
+ (void)setLaunchTime:(time_t)launchTime;

+ (const char *)nowUsingFormat:(TimeFormat)timeFormat;
+ (const char *)launchTimeString;
+ (const char *)localtime:(time_t)inTime usingFormat:(TimeFormat)timeFormat;
+ (const char *)stringForTimeFormat:(TimeFormat)timeFormat;

+ (NSString *)versionStringWithMessage:(NSString *)message;
+ (NSString *)osVersion;

@end
