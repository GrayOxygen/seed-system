//
//  AnnotatedLock.h
//  AppUtility
//
//  Created by Paul Herzog on 2/16/11.
//  Copyright 2011 Nuance Communications, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "Stacktrace.h"

#define LOCK(X) \
do { \
[X lock]; \
[X setName:[NSString stringWithFormat:@"Locked on line %s:%d\nstack:\n%@", __FILE__, __LINE__, BacktraceString()]]; \
} while (false)

#define UNLOCK(X) \
do { \
[X unlock]; \
} while (false)

#define TRY_LOCK(X) \
[AnnotatedLock tryLock:X \
			message:[NSString stringWithFormat:@"Locked on line %s:%d\nstack:\n%@", __FILE__, __LINE__, BacktraceString()]


#define TRY_RECURSIVE_LOCK(X) \
[AnnotatedLock tryRecursiveLock:X \
			message:[NSString stringWithFormat:@"Locked on line %s:%d\nstack:\n%@", __FILE__, __LINE__, BacktraceString()]


#define LOCK_BEFORE_DATE(X, D) \
[AnnotatedLock lock:X \
	 beforeDate:D \
		message:[NSString stringWithFormat:@"Locked on line %s:%d\nstack:\n%@", __FILE__, __LINE__, BacktraceString()]


#define RECURSIVE_LOCK_BEFORE_DATE(X, D) \
[AnnotatedLock recursiveLock:x \
	beforeDate:D \
	message:[NSString stringWithFormat:@"Locked on line %s:%d\nstack:\n%@", __FILE__, __LINE__, BacktraceString()]


@interface AnnotatedLock : NSObject {

}
+ (BOOL)tryLock:(NSLock *)inLock message:(NSString *)message;
+ (BOOL)tryRecursiveLock:(NSRecursiveLock *)inLock message:(NSString *)message;
+ (BOOL)lock:(NSLock *)inLock beforeDate:(NSDate *)limit message:(NSString *)message;
+ (BOOL)recursiveLock:(NSRecursiveLock *)inLock beforeDate:(NSDate *)limit message:(NSString *)message;

@end
