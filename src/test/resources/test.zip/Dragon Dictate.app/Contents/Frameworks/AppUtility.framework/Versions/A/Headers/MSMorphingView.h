//
//  MSMorphingView.h
//  Dictate
//
//  Created by Jacob Hazelgrove on 10/12/08.
//  Copyright © 2008, MacSpeech. All rights reserved.
//

/*
 Contains:
 • MSMorphingView
 • _MSPaneView
 */

#import <Cocoa/Cocoa.h>

@class MSPane;
@class _MSPaneView;

/*
 CoreAnimation based pane NSView subclass similar to the Workflow Steps sidebar pane in Dashcode. Used for editing advanced acoustics settings.
 */

@interface MSMorphingView : NSView {
	id dataSource;
	id delegate;
	
	NSPoint _padding;
	
	BOOL _creation;
}

@property (nonatomic, assign) id dataSource;
@property (nonatomic, assign) id delegate;
@property (nonatomic, assign) NSPoint padding;

- (void)reloadData;

- (_MSPaneView *)addPane:(MSPane *)pane animate:(BOOL)animate paneViewClassName:(NSString *)paneViewClassName;
- (BOOL)deletePaneAtIndex:(NSInteger)index animate:(BOOL)animate cascade:(BOOL)cascade; // Currently if value passed for cascade is NO, nothing is deleted
- (void)expandPane:(MSPane *)pane animate:(BOOL)animate;
- (void)expandPaneAtIndex:(NSInteger)index animate:(BOOL)animate;
- (void)collapseAllPanes;

- (void)forceLayout;	// Readjusts all the pane frames, preserving the currently expanded pane

- (void)setCreationMode:(BOOL)flag;	// Calls -setCreationMode:expandingPaneAtIndex: passing 0 for the index and NO for makeFirstResponder.
- (void)setCreationMode:(BOOL)creationMode expandingPaneAtIndex:(NSInteger)index makeFirstResponder:(BOOL)makeFirstResponder;	// Sets the creation mode; If creationMode is YES, then the pane index passed is used to expand that pane. If creationMode NO then the pane index is ignored. If makeFirstResponder is YES then an attempt will be made to make the pane at index first responder.
- (BOOL)creationMode;

@end

//	@interface DataSourceAndDelegateController : NSObject <MSMorphingViewDataSource, MSMorphingViewDelegate>
#pragma mark -
#pragma mark *** Data source protocol ***

@protocol MSMorphingViewDataSource <NSObject>

@required	// Will throw a build warning if @required methods are not implemented.

- (NSInteger)numberOfPanesInMorphingView:(MSMorphingView *)morphingView;
- (MSPane *)morphingView:(MSMorphingView *)morphingView paneAtIndex:(NSInteger)index;

@end


#pragma mark -
#pragma mark *** Delegate protocol ***

@protocol MSMorphingViewDelegate <NSObject>

@optional

// Collapsing
- (BOOL)morphingView:(MSMorphingView *)morphingView didCollapsePaneAtIndex:(NSInteger)index;
- (BOOL)morphingView:(MSMorphingView *)morphingView shouldCollapsePaneAtIndex:(NSInteger)index;
- (BOOL)morphingView:(MSMorphingView *)morphingView willCollapsePaneAtIndex:(NSInteger)index;

// Expanding
- (BOOL)morphingView:(MSMorphingView *)morphingView didExpandPaneAtIndex:(NSInteger)index;
- (BOOL)morphingView:(MSMorphingView *)morphingView shouldExpandPaneAtIndex:(NSInteger)index;
- (BOOL)morphingView:(MSMorphingView *)morphingView willExpandPaneAtIndex:(NSInteger)index;

- (BOOL)shouldAnimateMorphingView:(MSMorphingView *)morphingView;

// Deleting
- (void)morphingView:(MSMorphingView *)morphingView didDeletePanesWithIndexes:(NSIndexSet *)indexSet;
- (BOOL)morphingView:(MSMorphingView *)morphingView shouldDeletePanesWithIndexes:(NSIndexSet *)indexSet;

- (BOOL)deleteShouldUseCascadeInMorphingView:(MSMorphingView *)morphingView;

@end




/*
 Private NSView subclass for drawing individual panes. Has a content view that is used to hold the actual UI for the pane. Used in conjunction with NSViewController based MSPane instances.
 */

@interface _MSPaneView : NSView {
	MSPane *_pane;
	
	BOOL _creation;
	BOOL _collapsed;
	BOOL _mousedOver;
	BOOL _usesCheckButtonLabel;
	
	NSButton *_checkButton;
	
	NSTextFieldCell *_labelTextFieldCell;
	
	NSBox *_contentViewBox;
	NSView *_contentView;
	
	NSTrackingArea *_trackingArea;
	
	NSPoint lastDragLocation;
	BOOL _isResizing;
}

@property (nonatomic, assign) MSPane *pane;
@property (nonatomic, retain) NSView *contentView;
@property BOOL creation;
@property BOOL collapsed;
@property BOOL mousedOver;
@property BOOL usesCheckButtonLabel;

- (NSAttributedString *)collapsedLabelString;

- (NSButton *)checkButton;

- (void)expandNextPane;
- (void)expandPreviousPane;

- (NSBezierPath *)borderPathForRect:(NSRect)rect;
- (void)drawFocusRingIfApplicableForRect:(NSRect)rect;
- (void)drawLabelDecorationForRect:(NSRect)rect;

@end
