//
//  NSTextField+Additions.h
//  AppUtility
//
//  Created by Jacob Hazelgrove on 8/4/11.
//  Copyright 2011 Nuance Communications. All rights reserved.
//

#import <AppKit/AppKit.h>

@interface NSTextField (Additions)

@property (copy) NSString *stringValue;
@property (copy) NSString *hudEtchedStringValue;	// Uses NSLeftTextAlignment

+ (id)staticTextFieldWithStringValue:(NSString *)stringValue font:(NSFont *)font layerFriendly:(BOOL)layerFriendly;
- (void)setHUDEtchedStringValue:(NSString *)title alignment:(NSTextAlignment)textAlignment;

@end

@interface NSTextFieldCell (Additions)
- (NSAttributedString *)etchedAttributedStringValue;
@end
