//
//  DDAlert.h
//  DDAlert
//
//  Created by Jacob Hazelgrove on 9/3/11.
//  Copyright 2011 Nuance Communications. All rights reserved.
//

#import <AppKit/AppKit.h>

@interface DDAlert : NSAlert {
	void (^handler)();
}

/// \brief Runs the receiver modally as an alert sheet attached to a specified window.
/// \param window The parent window for the sheet.
/// \param handler The block called after the user has closed the panel. The argument passed in will be the constant positionally identifying the button clicked.
- (void)beginSheetModalForWindow:(NSWindow *)window completionHandler:(void (^)(NSInteger result))handler;

/// \brief Runs the receiver as an application-modal dialog and returns the constant positionally identifying the button clicked.
/// \param handler The block called after the user has closed the panel. The argument passed in will be the constant positionally identifying the button clicked.
- (void)beginWithCompletionHandler:(void (^)(NSInteger result))handler;

@end
