//
//  HUDWindowCloseButtonCell.h
//  AppUtility
//
//  Created by Jacob Hazelgrove on 1/24/12.
//  Copyright (c) 2012 Nuance Communications. All rights reserved.
//

#import <AppKit/AppKit.h>

@interface HUDWindowCloseButtonCell : NSButtonCell

@end
