//
//  NSBundle+DMLocalizedNibBundle.h
//  Auto Localization
//
//  Created by Jacob Hazelgrove on 11/12/11.
//  Copyright (c) 2011 Nuance Communications. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSBundle (DMLocalizedNibBundle)
+ (BOOL)deliciousLocalizingLoadNibFile:(NSString *)fileName externalNameTable:(NSDictionary *)context withZone:(NSZone *)zone;
@end
