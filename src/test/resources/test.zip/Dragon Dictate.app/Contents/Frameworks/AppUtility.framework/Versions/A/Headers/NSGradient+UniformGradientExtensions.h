//
//  NSGradient+UniformGradientExtensions.h
//  Dictate
//
//  Created by Jacob Hazelgrove on 6/8/09.
//  Copyright © 2009, MacSpeech. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSGradient (UniformGradientExtensions)

+ (NSGradient *)hudNormalGradient;
+ (NSGradient *)hudPressedGradient;

+ (NSGradient *)metalDimmedGradient;
+ (NSGradient *)metalNormalGradient;
+ (NSGradient *)metalPressedGradient;
+ (NSGradient *)paneBackgroundGradient;
+ (NSGradient *)audioSourcesPopUpButtonBackgroundGradient;

@end
