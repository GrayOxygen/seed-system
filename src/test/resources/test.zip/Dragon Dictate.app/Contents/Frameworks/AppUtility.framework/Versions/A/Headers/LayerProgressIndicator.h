//
//  LayerProgressIndicator.h
//  Scratch
//
//  Created by Jacob Hazelgrove on 11/16/10.
//  Copyright © 2010 Nuance Communications, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface SpinnerLayer : CALayer
@end


@interface LayerProgressIndicator : NSView {
	SpinnerLayer *spinnerLayer;
}

@property (retain) CALayer *spinnerLayer;

- (IBAction)startAnimation:(id)sender;
- (IBAction)stopAnimation:(id)sender;

@end
