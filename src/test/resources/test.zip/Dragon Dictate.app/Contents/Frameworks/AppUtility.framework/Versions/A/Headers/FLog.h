//
//  FLog.h
//  FLog
//  
//  Created by Jeff Ganyard on 10/9/09.
//  Copyright 2009 MacSpeech, Inc.. All rights reserved.
//

#define FLog(flag,...) F_Log(flag, __FILE__, __LINE__, __PRETTY_FUNCTION__, ##__VA_ARGS__);

#ifdef __cplusplus
extern "C" {
#endif
    
    extern void F_Log(NSString *flag, const char *file, NSInteger lineNumber, const char *funcName, NSString *format,...);

#ifdef __cplusplus
}
#endif
