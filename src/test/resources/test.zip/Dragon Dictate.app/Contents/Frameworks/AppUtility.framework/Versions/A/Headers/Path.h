//
//  Path.h
//  AppUtility
//
//  Created by Paul Herzog on 2/14/11.
//  Copyright 2011 Nuance Communications, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface Path : NSObject {

}
+ (BOOL)createPathAsNeeded:(NSString*)path;
+ (NSString *)fullyResolveAlias:(NSString *)filePath;
+ (NSString *)resolveSymlinkForFilePath:(NSString *)fullPath;
+ (void)removeDeadSymlinksInPath:(NSString *)path;
+ (BOOL)openEmptyPackage:(NSString *)packageName;
+ (NSString *)contentsPathForPackage:(NSString *)packageName;
+ (NSString *)logFolder;

@end

#ifdef __OBJC__

#define LEOPARD_OR_GREATER (NSAppKitVersionNumber > 910)

extern NSString * FullyResolveAlias(NSString * filePath);

#endif

