//
//  HUDPopUpButtonCell.h
//  Scratch
//
//  Created by Jeff Ganyard on 11/8/10.
//  Copyright 2010 Nuance Communications, Inc. All rights reserved.
//

// Extensive borrowing from:
//  BGHUDPopUpButtonCell.h
//  BGHUDAppKit
//
//  Created by BinaryGod on 5/31/08.
//
//  Copyright (c) 2008, Tim Davis (BinaryMethod.com, binary.god@gmail.com)
//  All rights reserved.


#import <Cocoa/Cocoa.h>

@interface HUDPopUpButtonCell : NSPopUpButtonCell {

}

- (void)drawArrowsInRect:(NSRect) frame;

@end
