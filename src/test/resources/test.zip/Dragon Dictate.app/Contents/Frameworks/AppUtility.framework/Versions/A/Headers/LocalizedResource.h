//
//  LocalizedResource.h
//  AppUtility
//
//  Created by Paul Herzog on 5/9/11.
//  Copyright 2011 N/A. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Language.h"

@interface LocalizedResource : NSObject {
@private
    Language *language;
}


#pragma mark -
#pragma mark Setup and Teardown
- (id)initWithLanguage:(Language *)resourceLanguage;
+ (LocalizedResource *)resourceWithLanguage:(Language *)resourceLanguage;


#pragma mark -
#pragma mark Resource Accessors
- (NSString *)stringForKey:(NSString *)key;
- (NSArray *)arrayForKey:(NSString *)key;
- (NSDictionary *)dictionaryForKey:(NSString *)key;


#pragma mark -
#pragma mark Bundle Registration
+ (void)registerLanguageBundle:(NSBundle *)languageBundle;
+ (void)unregisterLanguageBundle:(NSBundle *)languageBundle;
+ (void)removeResourceBundles;


#pragma mark -
#pragma mark Language Cache
+ (void)loadLanguage:(LanguageType)languageType;
+ (void)unloadLanguage:(LanguageType)languageType;
+ (void)removeLanguageCache;


#pragma mark -
#pragma mark Convenience Resource Accessors
+ (BOOL)localizationExistsForLanguage:(LanguageType)languageType;
+ (NSString *)stringForKey:(NSString *)key languageType:(LanguageType)languageType;
+ (NSArray *)arrayForKey:(NSString *)key languageType:(LanguageType)languageType;
+ (NSDictionary *)dictionaryForKey:(NSString *)key languageType:(LanguageType)languageType;

@end
