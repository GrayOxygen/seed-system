//
//  NSColor+UniformColorExtentions.h
//  Dictate
//
//  Created by Jacob Hazelgrove on 6/8/09.
//  Copyright © 2009, MacSpeech. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface NSColor (UniformColorExtentions)

+ (NSColor *)etchedShadowColor;

+ (NSColor *)metalControlDimmedBorderColor;	// To be used to draw the outside border of a custom metal control when the window is not main. Returns r:0.64 g:0.64 b:0.64 a:1.00
+ (NSColor *)metalControlNormalBorderColor;	// To be used to draw the outside border of a custom metal control when the window is main. Returns r:0.22 g:0.22 b:0.22 a:1.00

+ (NSColor *)badRecognitionTextColor;
+ (NSColor *)candidateRecognitionTextColor;
+ (NSColor *)goodRecognitionTextColor;

+ (NSColor *)keyWindowDividerColor;
+ (NSColor *)nonKeyWindowDividerColor;

+ (NSColor *)gradientPaneMouseOverBorderColor;
+ (NSColor *)gradientPaneNormalBorderColor;

- (NSString *)hexadecimalColor;



@end
