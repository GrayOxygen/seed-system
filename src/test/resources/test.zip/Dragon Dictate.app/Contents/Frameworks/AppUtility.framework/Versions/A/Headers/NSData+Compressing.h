//
//  NSData+Compressing.h
//  iListen
//
//  Created by SubDog on 9/14/07.
//  Copyright 2007 MacSpeech, Inc. All rights reserved.
//
//  http://deusty.blogspot.com/2007/07/gzip-compressiondecompression.html
//

#import <Foundation/NSData.h>


@interface NSData(Compressing)
// gzip compression utilities
- (NSData *)gzipInflate;
- (NSMutableData *)mutableGzipInflate;
- (NSData *)gzipDeflate;
@end
