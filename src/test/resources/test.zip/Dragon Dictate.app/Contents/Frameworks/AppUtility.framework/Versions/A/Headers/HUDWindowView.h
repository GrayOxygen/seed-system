//
//  HUDWindowView.h
//  Scratch
//
//  Created by Jacob Hazelgrove on 11/13/10.
//  Copyright © 2010 Nuance Communications, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface HUDWindowView : NSView {
	CGFloat bottomBorderThickness;
	CGFloat transparency;
}

@property (nonatomic) CGFloat bottomBorderThickness;
@property (nonatomic) CGFloat transparency;		// Default: 1.00

- (IBAction)close:(id)sender;

@end
