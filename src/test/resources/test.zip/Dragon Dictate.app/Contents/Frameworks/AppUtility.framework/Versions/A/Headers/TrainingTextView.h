//
//  TrainingTextView.h
//  iListen
//
//  Created by SubDog on 9/5/07.
//  Copyright 2007 MacSpeech, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#import "CoreAnimationFixes.h"

@interface TrainingTextView : NonAliasingTextView <NSAnimationDelegate>
{
    NSUInteger recognizedEnd;
	BOOL rejected;
	BOOL stringValid;
}

- (void)setString:(NSString *)string animate:(BOOL)animate;
- (void)setString:(NSString *)string;
- (NSString *)string;

- (void)setRecogizedEnd:(NSUInteger)inRecognizedEnd;
- (void)setRecogizedEndFromValue:(NSNumber *)inRecognizedEndValue;
- (NSUInteger)recognizedEnd;
- (void)showRejected;
@end
