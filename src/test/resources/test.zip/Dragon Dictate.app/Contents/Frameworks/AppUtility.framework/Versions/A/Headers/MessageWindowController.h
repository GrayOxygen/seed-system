//
//  MessageWindowController.h
//  AppUtility
//
//  Created by Paul Herzog on 3/5/11.
//  Based on LoadingWindowController by SubDog on 9/4/07.
//  Copyright 2011 Nuance Communications, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface MessageWindowController : NSWindowController {
    IBOutlet NSProgressIndicator * progressIndicator;
    IBOutlet NSTextField * progressText;
	double increment;
}
+ (id)messageWindowController;

- (void)setTitle:(NSString *)inTitle;
- (void)setProgressString:(NSString *)inProgressString;
- (void)setProgress:(NSString *)inProgressString;
- (void)setProgress:(NSString *)inProgressString indeterminate:(BOOL)indeterminate;
- (void)setProgressValue:(double)doubleValue;
- (void)incrementProgress;

- (double)increment;
- (void)setIncrement:(double)inc;
@end
