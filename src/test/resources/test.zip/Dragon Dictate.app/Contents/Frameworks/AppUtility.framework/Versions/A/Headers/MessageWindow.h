//
//  MessageWindow.h
//  AppUtility
//
//  Created by Paul Herzog on 3/5/11.
//  Copyright 2011 Nuance Communications, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#import "MessageWindowController.h"

@interface MessageWindow : NSObject {
    
}

+ (MessageWindowController *)startWithTitle:(NSString *)title text:(NSString *)progressText;
+ (MessageWindowController *)startWithTitle:(NSString *)title text:(NSString *)progressText indeterminate:(BOOL)indeterminate;
+ (BOOL)windowControllerExists;
+ (void *)finish;

@end
