//
//  NSString+MSWindowsLatinEncoding.h
//  iListen
//
//  Created by SubDog on 11/9/07.
//  Copyright 2007 MacSpeech, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface NSString(NuanceSorting)
- (NSComparisonResult)nuanceCompare:(NSString *)string;
@end
