//
//  Language.h
//  AppUtility
//
//  Created by Paul Herzog on 5/9/11.
//  Copyright 2011 N/A. All rights reserved.
//

#import <Foundation/Foundation.h>

// ----------------------------------------------------------
// Derived from v11/api/langid.h
//
// When the langid.h file changes, those changes must be 
// reflected here.
// ----------------------------------------------------------

typedef enum {
    kNoLanguage = -1,
    kUSEnglish = 0,
    kBritishEnglish,
    kFrench,
    kItalian,
    kGerman,
    kSpanish,
    kJapanese,
    kDutch,
    kPortuguese,
    kAustralianEnglish,
    kIndianEnglish,
    kSingaporeanEnglish,
    kLatinSpanish
} LanguageType;

typedef enum {
    kCoreNone = -1,
    kCoreENG = 1,
    kCoreFRA,
    kCoreNLD,
    kCoreDEU,
    kCoreITA,
    kCoreSPA
} CoreLanguageType;

@interface Language : NSObject {
@private
    LanguageType type;
    LanguageType fallback;
    CoreLanguageType coreType;
}

#pragma mark -
#pragma mark Properties
@property(readonly) NSString *name;
@property(readonly) LanguageType type;
@property(readonly) CoreLanguageType coreType;
@property(readonly) LanguageType fallback;

#pragma mark -
#pragma mark Setup and Teardown
- (Language *)initWithType:(LanguageType)languageType;

#pragma mark -
#pragma mark Convenience Methods
+ (Language *)languageForType:(LanguageType)languageType;
+ (Language *)preferredLanguage;
+ (LanguageType)fallbackForLanguage:(LanguageType)languageType;
+ (CoreLanguageType)coreTypeForLanguage:(LanguageType)languageType;

@end
