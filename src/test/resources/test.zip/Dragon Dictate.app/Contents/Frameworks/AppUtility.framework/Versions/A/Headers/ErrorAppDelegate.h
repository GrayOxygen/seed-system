//
//  ErrorAppDelegate.h
//  AppUtility
//
//  Created by Paul Herzog on 2/19/11.
//  Copyright 2011 Nuance Communications, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@protocol ErrorAppDelegate <NSObject>

@required
- (void)errorMessage:(NSString *)message;

@end
