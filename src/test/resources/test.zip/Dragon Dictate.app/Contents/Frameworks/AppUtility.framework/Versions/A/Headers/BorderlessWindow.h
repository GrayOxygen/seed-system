//
//  Window.h
//  Dictate
//
//  Created by Jacob Hazelgrove on 6/10/09.
//  Copyright © 2009, MacSpeech. All rights reserved.
//

#import <Cocoa/Cocoa.h>

// A generic NSPanel subclass with an NSBorderlessWindowMask style mask
@interface BorderlessWindow : NSPanel {

}

- (IBAction)bw_performClose:(id)sender;	// Sends windowShouldClose: message to the window or its delegate, and calls -close if the window should close

@end
