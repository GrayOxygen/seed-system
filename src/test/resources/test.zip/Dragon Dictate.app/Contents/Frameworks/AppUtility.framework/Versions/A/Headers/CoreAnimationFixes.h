//
//  CoreAnimationFixes.h
//  Dictate
//
//  Created by Jacob Hazelgrove on 4/20/09.
//  Copyright © 2009, MacSpeech. All rights reserved.
//

#import <Cocoa/Cocoa.h>

// Text antialiasing is horribly broken in layer backed views. The best 
// fix for this in our situation is to override drawRect: and call 
// CGContextSetShouldSmoothFonts(context, NO);
// For more details see: http://www.cocoabuilder.com/archive/message/cocoa/2008/10/15/220170
/*!
    @class       NonAntialiasingButton 
    @superclass  NSButton
    @brief    Provides fixes for text antialiasing in layer backed NSButton's
 
	Overrides drawRect: and invokes CGContextSetShouldSmoothFonts(context, NO) before calling super. This fix is only applied to layer backed NSButton's.
 
	For more details see: http://www.cocoabuilder.com/archive/message/cocoa/2008/10/15/220170
*/
@interface NonAntialiasingButton : NSButton
@end

/*!
	@class       NonAntialiasingMatrix 
	@superclass  NSMatrix
	@brief    Provides fixes for text antialiasing in layer backed NSMatrix's
 
	Overrides drawRect: and invokes CGContextSetShouldSmoothFonts(context, NO) before calling super. This fix is only applied to layer backed NSMatrix's.
 
	For more details see: http://www.cocoabuilder.com/archive/message/cocoa/2008/10/15/220170
*/
@interface NonAntialiasingMatrix : NSMatrix
@end

/*!
	@class       NonAliasingTextField 
	@superclass  NSTextField
	@brief    Provides fixes for text antialiasing in layer backed NSTextField's
 
	Overrides drawRect: and invokes CGContextSetShouldSmoothFonts(context, NO) before calling super. This fix is only applied to layer backed NSTextField's.
 
	For more details see: http://www.cocoabuilder.com/archive/message/cocoa/2008/10/15/220170
*/
@interface NonAliasingTextField : NSTextField
@end


/*!
	@class       NonAliasingTextView 
	@superclass  NSTextView
	@brief    Provides fixes for text antialiasing in layer backed NSTextView's
 
	Overrides drawRect: and invokes CGContextSetShouldSmoothFonts(context, NO) before calling super. This fix is only applied to layer backed NSTextViews's.
 
 For more details see: http://www.cocoabuilder.com/archive/message/cocoa/2008/10/15/220170
 */
@interface NonAliasingTextView : NSTextView
@end

/*!
 @class       NonAliasingPopUpButton 
 @superclass  NSPopUpButton
 @brief    Provides fixes for text antialiasing in layer backed NSTextField's
 
 Overrides drawRect: and invokes CGContextSetShouldSmoothFonts(context, NO) before calling super. This fix is only applied to layer backed NSTextField's.
 
 For more details see: http://www.cocoabuilder.com/archive/message/cocoa/2008/10/15/220170
 */
@interface NonAliasingPopUpButton : NSPopUpButton
@end

@interface FocusRingCorrectingPopUpButton : NonAliasingPopUpButton
@end


// Layer backed views don't allow drawing outside of the layers bounds, 
// this causes a 1 pixel wide focus ring to be drawn for NSTextField.
// FocusRingCorrectingEditableTextField fixes this in our current situation...
// However if the time comes that we need to have an NSTextField that will 
// animate down from below the toolbar a fix for the drawing will be needed.

/*!
	@class       FocusRingCorrectingEditableTextField 
	@superclass  NSTextField
	@brief    Provides a partial fix for issues involving focus rings in layer backed editable NSTextField's
	
	Layer backed views can only draw within the bounds of the layer. Presently this causes focus rings to be broken on editable NSTextField's. FocusRingCorrectingEditableTextField expands it's frame in initWithCoder: to accomidate the focus ring. FocusRingCorrectingEditableTextFieldCell then shrinks the draw rect back to normal so that focus ring is drawn properly. The layer draws the windows background color so that we don't have a hole in the window.
	
	For more details see: http://www.cocoabuilder.com/archive/message/cocoa/2008/10/15/220170
*/
@interface FocusRingCorrectingEditableTextField : NSTextField
@end

/*!
 @class       FocusRingCorrectingEditableTextFieldCell 
 @superclass  NSTextFieldCell
 @brief    See FocusRingCorrectingEditableTextField.
 */
@interface FocusRingCorrectingEditableTextFieldCell : NSTextFieldCell
@end
