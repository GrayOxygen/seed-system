//
//  NSString+MSWindowsLatinEncoding.h
//  iListen
//
//  Created by SubDog on 11/9/07.
//  Copyright 2007 MacSpeech, Inc. All rights reserved.
//

/*

For compatibility with v11 (MREC 18-) APIs, use this:
	CFSetDefaultNuanceStringEncoding((CFStringEncoding)kCFStringEncodingWindowsLatin1);
	NSSetDefaultNuanceStringEncoding((NSStringEncoding)NSWindowsCP1252StringEncoding);

For compatibility with v12 (MREC 20+) APIs, use this:
	CFSetDefaultNuanceStringEncoding((CFStringEncoding)kCFStringEncodingUTF8);
	NSSetDefaultNuanceStringEncoding((NSStringEncoding)NSUTF8StringEncoding);

*/

#ifdef __cplusplus
extern "C" {
#endif
	extern void CFSetDefaultNuanceStringEncoding(CFStringEncoding inCFStringEncoding);
	extern CFStringEncoding CFDefaultNuanceStringEncoding(void);

	extern void NSSetDefaultNuanceStringEncoding(NSStringEncoding inNSStringEncoding);
	extern NSStringEncoding NSDefaultNuanceStringEncoding(void);
#ifdef __cplusplus
}
#endif

#define kCFNuanceEncoding	CFDefaultNuanceStringEncoding()

@interface NSString(MSWindowsLatinEncoding)
+ (NSStringEncoding)nuanceNSStringEncoding;
+ (NSString *)stringWithNuanceEncodedString:(const char *)inNuanceEncodedString;
- (const char *)windowsLatinString;
- (NSData *)dataUsingWindowsLatinEncoding;
- (NSString *)percentEscaped;
- (NSString *)percentEscapedWithChars:(const NSString *)escChars;
- (NSString *)percentUnescaped;
@end
