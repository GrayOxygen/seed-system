//
//  HUDOutlineTextFieldCell.h
//  AppUtility
//
//  Created by Jacob Hazelgrove on 2/3/12.
//  Copyright (c) 2012 Nuance Communications. All rights reserved.
//

#import <AppKit/AppKit.h>

@interface HUDOutlineTextFieldCell : NSTextFieldCell

@end
