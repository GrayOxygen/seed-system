//
//  HUDPopover.h
//  AppUtility
//
//  Created by Jacob Hazelgrove on 6/10/09.
//  Copyright © 2009-2011, Nuance Communications. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#if MAC_OS_X_VERSION_MAX_ALLOWED <= MAC_OS_X_VERSION_10_6
enum {
    NSPopoverBehaviorApplicationDefined = 0,
    NSPopoverBehaviorTransient = 1,
    NSPopoverBehaviorSemitransient = 2
};
typedef NSInteger NSPopoverBehavior;
#endif

#define kDebugPopUpEditor 0

@interface HUDPopover : NSObject {
@private
	NSImageView *imageView;
	NSPanel *window;
	
	NSRect contentFrame;
	NSView *themeView;
	NSViewController *contentViewController;
	
	CGFloat scaleFactor;
	
	NSWindow *parentWindow;
	NSPoint lastAnchorPoint;
	
	id globalEventMonitor;
	id localEventMonitor;
	
	BOOL animates;
	BOOL shown;
	
	NSResponder *initialFirstResponder;
	
	void (^completionBlock)();
	
	NSPopoverBehavior behavior;
}

@property BOOL animates;	// Default: YES
@property (nonatomic, retain) IBOutlet NSViewController *contentViewController;
@property (copy) void (^completionBlock)(NSInteger returnCode);
@property (getter=isShown, readonly) BOOL shown;
@property (nonatomic, retain) IBOutlet NSResponder *initialFirstResponder;

// NSPopoverBehaviorApplicationDefined: doesn't install any even monitors; Default
// NSPopoverBehaviorTransient: installs local and global event monitors
// NSPopoverBehaviorSemitransient: doesn't install any event monitors
@property (nonatomic) NSPopoverBehavior behavior;

- (void)close;
- (void)closeWithReturnCode:(NSInteger)returnCode;
- (IBAction)performClose:(id)sender;

// Only NSMaxYEdge and NSMinYEdge are valid for the following methods. Passing NSMinXEdge and NSMinXEdge will led to undefined behavior.
- (void)moveToPoint:(NSPoint)point edge:(NSRectEdge)edge animate:(BOOL)animate;
- (void)showAtPoint:(NSPoint)point edge:(NSRectEdge)edge parentWindow:(NSWindow *)parentWindow;
- (void)showAtPoint:(NSPoint)point edge:(NSRectEdge)edge parentWindow:(NSWindow *)parentWindow offset:(CGFloat)offset;

- (void)showAtPoint:(NSPoint)point edge:(NSRectEdge)edge parentWindow:(NSWindow *)parentWindow completionHandler:(void (^)(NSInteger result))handler;

- (void)showRelativeToRect:(NSRect)positioningRect ofView:(NSView *)positioningView preferredEdge:(NSRectEdge)preferredEdge;
- (void)showRelativeToRect:(NSRect)positioningRect ofView:(NSView *)positioningView preferredEdge:(NSRectEdge)preferredEdge  completionHandler:(void (^)(NSInteger result))handler;

- (void)updateWindowFrameWithEdge:(NSRectEdge)edge;

@end
