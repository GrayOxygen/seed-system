//
//  Stacktrace.h
//  AppUtility
//
//  Created by Paul Herzog on 2/16/11.
//  Copyright 2011 Nuance Communications, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#define HandleDSXError(X, Y) [Stacktrace internalHandleDSXError:Y message:X file:__FILE__ line:__LINE__]


@interface Stacktrace : NSObject {

}
+ (void)internalHandleDSXError:(NSInteger)inError message:(const char  *)inMessage file:(const char *)inFile line:(NSInteger)inLine;

@end

#ifdef __cplusplus
extern "C" {
#endif

	NSString * BacktraceString(void);

#ifdef __cplusplus
}
#endif
		
//void CleanUpDebuggingFiles();
//void StartKillerThread()
