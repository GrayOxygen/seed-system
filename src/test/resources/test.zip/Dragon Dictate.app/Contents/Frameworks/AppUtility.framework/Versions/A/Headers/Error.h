//
//  Error.h
//  AppUtility
//
//  Created by Paul Herzog on 2/18/11.
//  Copyright 2011 Nuance Communications, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

extern NSString *DictateErrorDomain;
extern const NSInteger DDInterfaceAlreadyExistsError;

@interface Error : NSObject {

}

+ (NSError *)errorForPath:(NSString *)path reason:(NSString *)reason;
+ (NSError *)unspecifiedError;
+ (NSError *)errorWithDomain:(NSString *)domain code:(NSInteger)errorCode localizedDesc:(NSString *)localizedDesc;

@end
