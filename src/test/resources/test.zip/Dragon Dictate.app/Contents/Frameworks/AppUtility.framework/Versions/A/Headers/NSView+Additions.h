//
//  NSView+Additions.h
//  Commander
//
//  Created by Jacob Hazelgrove on 3/24/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface NSView (Additions)

- (void)addFullCoverageSubview:(NSView *)subview;
- (void)addFullCoverageSubview:(NSView *)subview withOffset:(CGFloat)offset fromEdge:(NSRectEdge)edge;

- (void)replaceSubview:(NSView *)oldView withFullCoverageView:(NSView *)newView;
- (void)replaceSubview:(NSView *)oldView withFullCoverageView:(NSView *)newView withOffset:(CGFloat)offset fromEdge:(NSRectEdge)edge;

@end
