//
//  HUDTextFieldCell.h
//  Dragoness
//
//  Created by Jacob Hazelgrove on 8/19/11.
//  Copyright 2011 Nuance Communications, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface HUDTextFieldCell : NSTextFieldCell

@end
