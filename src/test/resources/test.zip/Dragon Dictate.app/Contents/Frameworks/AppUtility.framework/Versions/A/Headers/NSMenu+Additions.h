//
//  NSMenu+Additions.h
//  AppUtility
//
//  Created by Jacob Hazelgrove on 07/02/2012.
//  Copyright (c) 2012 Nuance Communications. All rights reserved.
//

#import <AppKit/AppKit.h>

@interface NSMenu (Additions)

- (void)localizeMenuItem:(NSMenuItem *)menuItem withTable:(NSString *)table;
- (void)localizeWithTable:(NSString *)table;

@end
