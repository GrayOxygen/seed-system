//
//  DisclosureView.h
//  AppUtility
//
//  Created by Jacob Hazelgrove on 4/27/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

// Extracted from WordListController

@interface DisclosureView : NSView {
	NSButton *button;
	NSView *contentView;		// When collapsed is sent setHidden: gaining all the benifits from that
	NSView *obscureView;
	NSView *previousView;
	NSUInteger previousViewAutoresizingMask;
	BOOL expanded;				// Assumes that the view is NOT expanded at initialization time
	CGFloat initialHeight;
}

@property (nonatomic, assign) IBOutlet NSButton *button;
@property (nonatomic, assign) IBOutlet NSView *contentView;
@property (nonatomic, assign) IBOutlet NSView *obscureView;	// The contentView is ordered below obscureView, this allows expanding with a reveal from below.
@property (nonatomic, assign) IBOutlet NSView *previousView;
@property (nonatomic, assign) NSUInteger previousViewAutoresizingMask;
@property (nonatomic, readonly) BOOL expanded;

- (IBAction)toggle:(id)sender;
- (void)toggleWithAnimation:(BOOL)animate;

- (void)expandWithAnimation:(BOOL)animate;
- (void)collapseWithAnimation:(BOOL)animate;

@end
