//
//  HUDCheckButtonCell.h
//  AppUtility
//
//  Created by Jacob Hazelgrove on 4/30/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface HUDCheckButtonCell : NSButtonCell

@end
