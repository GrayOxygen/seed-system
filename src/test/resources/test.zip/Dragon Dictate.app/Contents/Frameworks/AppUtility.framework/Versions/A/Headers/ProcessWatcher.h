//
//  ProcessWatcher.h
//  ProcessWatcher
//
//  Created by Jacob Hazelgrove on 1/17/12.
//  Copyright (c) 2012 Nuance Communications. All rights reserved.
//

#import <Foundation/Foundation.h>

enum {
	ProcessTerminatedEventType = 0,
	ProcessActivatedEventType = 1,
};
typedef NSUInteger ProcessEventType;

@interface ProcessWatcher : NSObject {
	NSRunningApplication *application;
	
	void (^eventHandler)();
}

@property (retain, readonly) NSRunningApplication *application;
@property (nonatomic, copy) void (^eventHandler)(ProcessEventType eventType);

- (BOOL)startWatchingApplication:(NSRunningApplication *)application;	// Returns NO if application is nil or the application has already terminated.
- (void)stopWatching;

@end
