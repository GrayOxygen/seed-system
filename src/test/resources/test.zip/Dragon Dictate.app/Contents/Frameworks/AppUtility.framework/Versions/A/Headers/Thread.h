//
//  Thread.h
//  AppUtility
//
//  Created by Paul Herzog on 2/18/11.
//  Copyright 2011 Nuance Communications, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#ifdef __cplusplus
extern "C" {
#endif
char * GetCurrentThreadName(void);

#define SET_THREAD_NAMES (1)
#if SET_THREAD_NAMES
void SetCurrentThreadName(NSString * inThreadName);
#endif // SET_THREAD_NAMES
#ifdef __cplusplus
}
#endif

@interface Thread : NSObject {

}


@end
