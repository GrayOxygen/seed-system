//
//  Fatal.h
//  AppUtility
//
//  Created by Paul Herzog on 2/18/11.
//  Copyright 2011 Nuance Communications, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

extern NSString *kFailureDomainInit;
extern NSString *kFailureDomainRun;

@interface Fatal : NSObject {
}
+ (NSString *)tail:(NSString *)inFileName maxBytes:(NSUInteger)maxBytes encoding:(NSStringEncoding)encoding;
+ (NSString *)formatFatalErrorEmail:(NSString *)inMessage profileText:(NSString *)profileText;
+ (NSString *)emailBodySafeString:(NSString *)rawString;
+ (NSArray *)syslogText;
@end


#define FatalErrorIf(test)										\
do {														\
if (test)												\
{														\
FatalError(CFSTR("Assertion Failure: " #test));		\
}														\
} while (false)

#define FatalErrorIfNot(test)									\
do {														\
if (!(test))											\
{														\
FatalError(CFSTR("Assertion Failure: NOT " #test));	\
}														\
} while (false)

#define FatalError(X) FatalErrorWithFileAndLine(X, NULL, __FILE__, __LINE__)
#define FatalException(X, Y) FatalErrorWithFileAndLine(X, Y, __FILE__, __LINE__)

#ifdef __cplusplus
extern "C" {
#endif
	void FatalErrorWithFileAndLine(CFStringRef message, void *inException, const char *inFile, NSInteger inLine);
#ifdef __cplusplus
	}
#endif
		

