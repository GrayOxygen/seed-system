//
//  DebugLog.h
//  AppUtility
//
//  Created by Paul Herzog on 2/18/11.
//  Copyright 2011 Nuance Communications, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "ErrorAppDelegate.h"


typedef struct {
	char fileNameBase[64];
	FILE * file;
	char lastTimeStamp[20];
	char * fullFileName;
} DebugFileInfo;



#define DUMP_FRAMES \
do { \
  DDFatal(@"Trace from %s, %s, %d\n", __PRETTY_FUNCTION__, __FILE__, __LINE__); \
  dump_frames(); \
} while (false)

@interface DebugLogInfo : NSObject 

+ (NSString *)debugFolderPath;
+ (void)setDelegate:(id<ErrorAppDelegate>)appDelegate;
+ (id<ErrorAppDelegate>)delegate;
+ (void)forwardFatalErrorMessage:(NSString *)errorText;
@end

#ifdef __cplusplus
extern "C" {
#endif
	void dump_frames(void);
#ifdef __cplusplus
	}
#endif
