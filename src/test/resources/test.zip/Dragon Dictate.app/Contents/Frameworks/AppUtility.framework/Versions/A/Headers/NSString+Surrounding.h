//
//  NSString+Surrounding.h
//  AppUtility
//
//  Created by Paul Herzog on 9/24/11.
//  Copyright 2011 Nuance Communications, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString(DXSurrounding)
- (NSUInteger)lengthOfPrefixInCharacterSet:(NSCharacterSet *)characterSet;
- (NSUInteger)lengthOfSuffixInCharacterSet:(NSCharacterSet *)characterSet;
- (NSString *)stringByEscapingControlCharacters;
@end
