//
//  HUDSwitch.h
//  HUDSwitch
//
//  Created by Jacob Hazelgrove on 11/24/10.
//  Copyright 2010 MacSpeech, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface HUDSwitch : NSButton {
@private	
	BOOL on;
	
	id control;
	
	SEL internalAction;
	id internalTarget;
}

@property (nonatomic, getter=isOn) BOOL on;

- (void)setOn:(BOOL)on animate:(BOOL)animate;

@end
