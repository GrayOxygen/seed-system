//
//  BNRCrypto.h
//  PhoneSpeedTest
//
//  Created by Adam Preble on 4/8/10.
//  Copyright 2010 Big Nerd Ranch. All rights reserved.
//

void BNRRandomBytes(void *buffer, int length);