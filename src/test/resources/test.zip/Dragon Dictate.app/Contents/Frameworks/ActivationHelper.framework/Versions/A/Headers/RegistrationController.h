//
//  RegistrationController.h
//  RegistrationClient
//
//  Created by Jeff Ganyard on 8/23/10.
//  Copyright 2011-2012 Nuance Communications, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "RegistrationInfo.h"
#import "MachineInfo.h"
#import "ProductInfo.h"
#import "UpgradeWindowInfo.h"
#import "ActivationAgent.h"
#import "ActivationHelper.h"

@class INCService2;
@class WebView;

@interface RegistrationController : NSWindowController<NSWindowDelegate>
{	
	NSWindow *emailProblemWindow;
    
    NSMutableDictionary *CompiledInfo; //used to send the information to the soap service.
	
    BOOL skipRegistration;
    BOOL registrationOnly;
}
#define kRegistrationValidationCompleteNotification @"com.nuance.RegistrationController.RegistrationValidationComplete"
//NU-ARC
//should be weak when we switch to arc but weak is not currently available
@property (assign) IBOutlet RegistrationInfo *regInfo;
@property (assign) IBOutlet ProductInfo *prodInfo;
@property (assign) IBOutlet MachineInfo *macInfo;
@property (assign) IBOutlet UpgradeWindowInfo *upgradeInfo;
@property (assign) IBOutlet NSWindow *progressWindow;
@property (assign) IBOutlet NSTextField *progressText;
@property (assign) IBOutlet NSProgressIndicator *progressBar;
@property (assign) IBOutlet NSButton *skipButton;
@property (assign) IBOutlet NSTextField *activationText;
@property (assign) IBOutlet NSButton *skipUpgradeButton;
@property (assign) IBOutlet NSTextField *upgradeText;
@property (assign) IBOutlet NSWindow *upgradeWindow;
@property (assign) IBOutlet WebView *privacyPolicy;
@property (assign) IBOutlet NSButton *purchaseSerialButton;
@property (assign) IBOutlet NSTextField *serialInformation;
@property (assign) IBOutlet NSTextField *trialModeInfo;

@property (strong, nonatomic) ActivationAgent *activator;

- (void)promptUserToDeactivate;
- (id)initWithActivator:(ActivationAgent *)activator;

- (BOOL)validateRequiredFields;
- (void)reportNetworkError:(NSError *)error;

- (IBAction)quit:(id)sender;
- (IBAction)registerLater:(id)sender;
- (IBAction)registerNow:(id)sender;

- (IBAction)purchaseSerialNumber:(id)sender;

- (IBAction)tryAgain:(id)sender;
- (IBAction)goToWebStore:(id)sender;

- (BOOL)processRegistrationCandidateString:(NSString *)candidateString;
@end
