//
//  ActivationHelper.h
//  ActivationHelper
//
//  Created by Colin on 1/11/13.
//  Copyright (c) 2013 Nuance. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ActivationAgent.h"

@class RegistrationController;

@interface ActivationHelper : NSObject
{
    RegistrationController  *registrationController;
}

@property (copy,readonly)     NSString * productID;         // the product ID for the application
@property (copy,readonly)     NSString * applicationLongName;
@property (copy,readonly)     NSString * licenseFilePath;    // the license file where license information is saved
@property (copy, readonly)      NSString * saveLocation;
@property (assign,readonly)     BOOL       vla;             // VLA mode
@property (assign, readonly)    ActivationAgent         *agent;

- (id)initWithLicenseFile:(NSString *)inLicenseFilePath saveLocation:(NSString *)saveLocation applicationLongName:(NSString *)appName productID:(NSString *)prodID;

- (id)initWithLicenseFile:(NSString *)inLicenseFilePath saveLocation:(NSString *)saveLocation volumeLicensing:(BOOL)VLAflag applicationLongName:(NSString *)appName productID:(NSString *)prodID;

- (void)registerApp;
- (void)activateApp;
- (void)deactivateApp;

-(void)ShowRegWindow;

@end
