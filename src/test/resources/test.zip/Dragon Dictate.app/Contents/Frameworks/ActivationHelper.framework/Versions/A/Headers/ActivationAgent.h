//
//  ActivationAgent.h
//  ActivationAgent
//
//  Created by Boisy Pitre on 12/22/11.
//  Copyright (c) 2011 Nuance Communications. All rights reserved.
//

#import <Foundation/Foundation.h>

@class INCService1;
@class INCService2;
@class SoapRequest;

#define LAUNCHES_BEFORE_EXPIRATION  5

@interface ActivationAgent : NSObject
{
}

#define kActivationAgentActivationCompleteNotificationName      @"com.nuance.ActivationAgent.ActivationComplete"
#define kActivationAgentDeactivationCompleteNotificationName    @"com.nuance.ActivationAgent.DeactivationComplete"

// Preferences Keys
#define kSerialNumber                                           @"_S"
#define kUpgradeSerialNumber                                    @"_U"
#define kActivationCodeEncrypted                                @"_X"
#define kActivationCode                                         @"_Y"
#define kLaunchCount                                            @"_C"

@property (strong) INCService1 *service;        // a reference to our Web Service object
@property (copy) NSString *candidateSerialNumber;      // the potential serial number to activate or deactivate
@property (copy) NSString *serialNumber;      // the serial number to activate or deactivate
@property (copy) NSString *upgradeSerialNumber;      // the upgrade serial number to activate or deactivate
@property (copy,readonly) NSString *hwFingerprint;     // the hardware fingerprint generated
@property (copy,readonly) NSString *productID;         // the product ID for the application
@property (copy,readonly) NSString *version;           // the version number of the product
@property (copy, readonly) NSString *languageID;        //the language ID of the product, EN or DE/FR
@property (assign,readonly) id       resultCode;         // the result code for the activation/deactivation
@property (copy,readonly) NSString        *activationCode;
@property (assign,readonly) BOOL       activated;        // set to TRUE if the product is activated, or FALSE if not
@property (assign,readonly) BOOL       upgrading;        // set to TRUE if the product is activating an upgrade serial number, or FALSE otherwise.

@property (assign,readonly) NSInteger launchCount;       // the current launch count
@property (copy,readonly) NSString        *notificationToSend;
@property (strong) SoapRequest     *request;


@property (copy)          NSString    *licenseFilePath;    // the license file where license information is referenced
@property (copy)          NSString    *saveLocation;    // the license file where license information is saved
@property (copy)    NSMutableDictionary *licensePlist;

@property (assign)          BOOL        vla;             // VLA mode
@property (assign,readonly) BOOL       expired;          // set to TRUE if the product is expired, or FALSE if not


@property (copy) NSString * applicationLongName; //Name of the application used for display in error messages

/*
 Initializer
 */
- (id)initWithLicenseFile:(NSString *)licenseFilePath saveLocation:(NSString *)saveLocation applicationLongName:(NSString *)appName productID:(NSString *)prodID;

/*
 Designated initializer for handling VLA or standard licenses
 */
- (id)initWithLicenseFile:(NSString *)licenseFilePath saveLocation:(NSString *)saveLocation volumeLicensing:(BOOL)VLAflag applicationLongName:(NSString *)appName productID:(NSString *)prodID;

/*
 Called to activate a serial number
 */
- (void)activate:(id)sender;
/* Called to activate an upgrade serial number and the full serial number*/
- (void)upgrade:(id)sender;
/*
 Called to deactivate a serial number
 */
- (void)deactivate:(id)sender;

@end
