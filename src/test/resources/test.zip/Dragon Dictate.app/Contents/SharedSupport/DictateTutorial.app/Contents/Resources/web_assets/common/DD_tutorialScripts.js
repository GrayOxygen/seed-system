//  A common location for our Java Scripts so that we do not have multiple copies all over the place
//
//  Created by Colin Taylor on 2/22/12.
//  Copyright (c) 2012 Nuance Communications. All rights reserved.


function micImageSwap(desiredMicState)
{
    if(desiredMicState == "on")
    {
        tempObj = document.getElementById("dgnDictate_off");
        tempObj.style.display = "none";	
        tempObj2 = document.getElementById("dgnDictate_on");
        tempObj2.style.display = "block";	
    }
    else if(desiredMicState == "off")
    {
        tempObj = document.getElementById("dgnDictate_off");
        tempObj.style.display = "block";	
        tempObj2 = document.getElementById("dgnDictate_on");
        tempObj2.style.display = "none";	
    }
    return;	
}

function toggleMic(desiredMicState)
{
    micImageSwap(desiredMicState);
    dictateTutorial.setMicStatus(desiredMicState);
    
}
<!-- We have to preload these so that the image loads before the text is on screen. -->
function preloader() {
	Insertion = new Image()
	Insertion.src = "resources/Insertion.png"
	
	InsertionHidden = new Image()
	InsertionHidden.src = "resources/InsertionHidden.png"
}

window.onload=preloader()
